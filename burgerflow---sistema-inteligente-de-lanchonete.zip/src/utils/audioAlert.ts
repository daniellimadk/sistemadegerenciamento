/**
 * Web Audio API based notification sounds.
 * Generates rich synthetic chimes with no external file dependency.
 */

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  try {
    if (!audioCtx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        audioCtx = new AudioContextClass();
      }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  } catch (e) {
    console.warn('AudioContext unavailable:', e);
    return null;
  }
}

export function playOrderAlertSound(volume: number = 0.8) {
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(Math.max(0.1, Math.min(1, volume)), now);
  masterGain.connect(ctx.destination);

  // Friendly three-tone diner order chime: G5 -> C6 -> E6
  const notes = [
    { freq: 783.99, start: 0, duration: 0.18 },
    { freq: 1046.50, start: 0.15, duration: 0.22 },
    { freq: 1318.51, start: 0.32, duration: 0.45 },
  ];

  notes.forEach(({ freq, start, duration }) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now + start);

    gain.gain.setValueAtTime(0, now + start);
    gain.gain.linearRampToValueAtTime(0.5, now + start + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, now + start + duration);

    osc.connect(gain);
    gain.connect(masterGain);

    osc.start(now + start);
    osc.stop(now + start + duration);
  });
}

export function playReadyAlertSound(volume: number = 0.8) {
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(Math.max(0.1, Math.min(1, volume)), now);
  masterGain.connect(ctx.destination);

  // Double bell: high chime
  [0, 0.18].forEach(offset => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(1174.66, now + offset); // D6

    gain.gain.setValueAtTime(0.4, now + offset);
    gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.3);

    osc.connect(gain);
    gain.connect(masterGain);

    osc.start(now + offset);
    osc.stop(now + offset + 0.3);
  });
}

export function playWarningSound(volume: number = 0.8) {
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(Math.max(0.1, Math.min(1, volume)), now);
  masterGain.connect(ctx.destination);

  // Low warning tone
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(329.63, now); // E4
  osc.frequency.linearRampToValueAtTime(261.63, now + 0.25); // C4

  gain.gain.setValueAtTime(0.3, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

  osc.connect(gain);
  gain.connect(masterGain);

  osc.start(now);
  osc.stop(now + 0.35);
}
