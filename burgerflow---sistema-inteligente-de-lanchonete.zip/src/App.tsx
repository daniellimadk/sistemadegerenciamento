/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext.tsx';
import { Header } from './components/Header.tsx';
import { Sidebar } from './components/Sidebar.tsx';
import { DashboardView } from './views/DashboardView.tsx';
import { OrdersView } from './views/OrdersView.tsx';
import { KitchenView } from './views/KitchenView.tsx';
import { PosView } from './views/PosView.tsx';
import { CashRegisterView } from './views/CashRegisterView.tsx';
import { InventoryView } from './views/InventoryView.tsx';
import { ProductsView } from './views/ProductsView.tsx';
import { FinancialView } from './views/FinancialView.tsx';
import { DeliveryView } from './views/DeliveryView.tsx';
import { CustomersView } from './views/CustomersView.tsx';
import { SuppliersView } from './views/SuppliersView.tsx';
import { SettingsView } from './views/SettingsView.tsx';
import { CustomerMenuView } from './views/CustomerMenuView.tsx';
import { OrderTrackingView } from './views/OrderTrackingView.tsx';
import { Loader2 } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { currentView, loading } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (loading) {
    return (
      <div className="h-screen w-screen flex flex-col items-center justify-center bg-stone-900 text-white gap-3">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
        <p className="text-xs font-semibold tracking-wide text-stone-300">
          Iniciando o BurgerFlow...
        </p>
      </div>
    );
  }

  // Customer Menu or Tracking takes over full screen for authentic experience
  if (currentView === 'customer-menu') {
    return <CustomerMenuView />;
  }

  if (currentView === 'order-tracking') {
    return <OrderTrackingView />;
  }

  return (
    <div className="min-h-screen bg-stone-50 flex flex-col lg:flex-row antialiased selection:bg-amber-500 selection:text-white">
      {/* Sidebar Navigation */}
      <Sidebar
        isMobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
      />

      {/* Main View Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <Header onToggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)} />

        <main className="flex-1 overflow-y-auto">
          {currentView === 'dashboard' && <DashboardView />}
          {currentView === 'orders' && <OrdersView />}
          {currentView === 'kitchen' && <KitchenView />}
          {currentView === 'pos' && <PosView />}
          {currentView === 'cash-register' && <CashRegisterView />}
          {currentView === 'inventory' && <InventoryView />}
          {currentView === 'products' && <ProductsView />}
          {currentView === 'financial' && <FinancialView />}
          {currentView === 'delivery' && <DeliveryView />}
          {currentView === 'customers' && <CustomersView />}
          {currentView === 'suppliers' && <SuppliersView />}
          {currentView === 'settings' && <SettingsView />}
        </main>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
