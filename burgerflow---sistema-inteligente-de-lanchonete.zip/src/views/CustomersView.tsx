import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type { Customer, Coupon } from '../types/index.ts';
import { formatCurrency, formatDateTime } from '../utils/formatters.ts';
import {
  Users,
  Award,
  Tag,
  Plus,
  Search,
  Phone,
  Mail,
  ShoppingBag,
  Ticket,
  CheckCircle2,
  Calendar
} from 'lucide-react';

export const CustomersView: React.FC = () => {
  const { customers, coupons, orders } = useApp();

  const [search, setSearch] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.phone.includes(search) ||
      (c.email || '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-900">
            Clientes & Programa de Fidelidade
          </h1>
          <p className="text-xs sm:text-sm text-stone-500 mt-0.5">
            Histórico de consumo por cliente, pontos de fidelidade e cupons promocionais.
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
          <span className="text-xs text-stone-500 font-medium">Clientes Cadastrados</span>
          <div className="text-2xl font-bold text-stone-900 font-mono mt-2">
            {customers.length}
          </div>
          <div className="text-[11px] text-stone-500 mt-1">
            Base ativa de consumidores recorrentes
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
          <span className="text-xs text-stone-500 font-medium">Pontos de Fidelidade Emitidos</span>
          <div className="text-2xl font-bold text-amber-700 font-mono mt-2">
            {customers.reduce((acc, c) => acc + c.points, 0)} pts
          </div>
          <div className="text-[11px] text-stone-500 mt-1">
            1 ponto a cada R$ 1,00 em compras
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
          <span className="text-xs text-stone-500 font-medium">Cupons Ativos</span>
          <div className="text-2xl font-bold text-emerald-700 font-mono mt-2">
            {coupons.filter(c => c.active).length}
          </div>
          <div className="text-[11px] text-stone-500 mt-1">
            Campanhas vigentes no cardápio online
          </div>
        </div>
      </div>

      {/* Split: Customers List & Active Coupons */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Customers Table (8 cols) */}
        <div className="lg:col-span-8 bg-white rounded-xl border border-stone-200 shadow-2xs p-5 space-y-4">
          <div className="flex items-center justify-between gap-3">
            <h3 className="font-bold text-sm text-stone-900">Base de Clientes</h3>
            <div className="relative w-64">
              <Search className="w-3.5 h-3.5 text-stone-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Buscar por nome ou fone..."
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-none"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Cliente</th>
                  <th className="py-2.5 px-3">Telefone</th>
                  <th className="py-2.5 px-3">Pedidos</th>
                  <th className="py-2.5 px-3">Total Comprado</th>
                  <th className="py-2.5 px-3">Pontos</th>
                  <th className="py-2.5 px-3 text-right">Último Pedido</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredCustomers.map((cust) => (
                  <tr key={cust.id} className="hover:bg-stone-50/80">
                    <td className="py-2.5 px-3 font-semibold text-stone-900">
                      {cust.name}
                    </td>
                    <td className="py-2.5 px-3 text-stone-600 font-mono">
                      {cust.phone}
                    </td>
                    <td className="py-2.5 px-3 font-mono font-bold text-stone-800">
                      {cust.ordersCount}
                    </td>
                    <td className="py-2.5 px-3 font-mono font-bold text-stone-900">
                      {formatCurrency(cust.totalSpent)}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="font-mono font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                        {cust.points} pts
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-stone-500 text-[11px]">
                      {cust.lastOrderDate ? formatDateTime(cust.lastOrderDate) : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Coupons List (4 cols) */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-stone-200 shadow-2xs p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <h3 className="font-bold text-sm text-stone-900 flex items-center gap-2">
              <Ticket className="w-4 h-4 text-amber-600" />
              Cupons de Desconto
            </h3>
          </div>

          <div className="space-y-3">
            {coupons.map((coupon) => (
              <div
                key={coupon.id}
                className="p-3.5 rounded-xl border border-dashed border-amber-300 bg-amber-50/40 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-xs bg-amber-100 text-amber-900 px-2 py-0.5 rounded-sm">
                    {coupon.code}
                  </span>
                  <span className="font-mono font-bold text-xs text-amber-900">
                    {coupon.discountType === 'fixed' ? formatCurrency(coupon.value) : `${coupon.value}%`} OFF
                  </span>
                </div>

                <div className="text-[11px] text-stone-600 space-y-0.5">
                  <div>Pedido mínimo: <strong>{formatCurrency(coupon.minOrderValue)}</strong></div>
                  <div>Usos realizados: <strong>{coupon.usageCount}</strong></div>
                  <div>Validade: <strong>{coupon.validUntil}</strong></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
