import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type { Order, OrderStatus } from '../types/index.ts';
import {
  formatTimeOnly,
  getElapsedTimeInMinutes,
  ORDER_TYPE_LABELS
} from '../utils/formatters.ts';
import {
  ChefHat,
  Flame,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Play,
  RotateCcw,
  Volume2,
  Filter,
  Check
} from 'lucide-react';

export const KitchenView: React.FC = () => {
  const { orders, updateOrderStatus, settings, testSound } = useApp();

  const [selectedStation, setSelectedStation] = useState<string>('Geral');

  // Filter kitchen active orders:
  // Recebido, Aguardando confirmação, Confirmado, Em Preparação
  const kitchenOrders = orders.filter((o) =>
    o.status === 'recebido' ||
    o.status === 'aguardando_confirmacao' ||
    o.status === 'confirmado' ||
    o.status === 'em_preparacao'
  ).sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  // Recent completed in kitchen (status === 'pronto')
  const readyOrders = orders.filter(o => o.status === 'pronto').slice(0, 4);

  const stations = settings.kitchenStations || ['Geral', 'Chapa', 'Fritadeira', 'Montagem', 'Bebidas'];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-stone-900 text-white p-4 sm:p-6 rounded-2xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500 rounded-xl text-stone-950 font-bold shadow-md">
            <ChefHat className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
              KDS — Monitor da Cozinha
              <span className="text-xs bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded-full font-mono">
                {kitchenOrders.length} na fila
              </span>
            </h1>
            <p className="text-xs text-stone-400 mt-0.5">
              Fila de produção sincronizada em tempo real com alertas de tempo.
            </p>
          </div>
        </div>

        {/* Station switcher & sound alert */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center bg-stone-800 p-1 rounded-xl border border-stone-700">
            {stations.map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setSelectedStation(st)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  selectedStation === st
                    ? 'bg-amber-500 text-stone-950 font-bold shadow-xs'
                    : 'text-stone-300 hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={testSound}
            className="p-2.5 bg-stone-800 hover:bg-stone-700 text-amber-400 rounded-xl border border-stone-700 transition-colors"
            title="Testar alarme sonoro"
          >
            <Volume2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {kitchenOrders.length === 0 ? (
          <div className="col-span-full py-20 text-center bg-white rounded-2xl border border-stone-200 shadow-2xs space-y-3">
            <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-stone-900">Cozinha Zerada!</h3>
            <p className="text-xs text-stone-500 max-w-sm mx-auto">
              Não há pedidos pendentes no momento. Novos pedidos aparecerão automaticamente aqui com aviso sonoro.
            </p>
          </div>
        ) : (
          kitchenOrders.map((order) => {
            const elapsed = getElapsedTimeInMinutes(order.createdAt);
            const isCritical = elapsed >= 25;
            const isWarning = elapsed >= 15 && !isCritical;

            let cardBorder = 'border-stone-200';
            let headerBg = 'bg-stone-50 text-stone-900';
            if (isCritical) {
              cardBorder = 'border-rose-500 ring-2 ring-rose-500/20';
              headerBg = 'bg-rose-500 text-white';
            } else if (isWarning) {
              cardBorder = 'border-amber-500 ring-2 ring-amber-500/20';
              headerBg = 'bg-amber-500 text-stone-950';
            }

            return (
              <div
                key={order.id}
                className={`bg-white rounded-2xl border ${cardBorder} shadow-sm overflow-hidden flex flex-col justify-between transition-all`}
              >
                {/* Card Header */}
                <div className={`p-4 ${headerBg} flex items-center justify-between`}>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-lg">
                      #{order.orderNumber}
                    </span>
                    <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                      isCritical ? 'bg-white text-rose-700' : isWarning ? 'bg-stone-950 text-amber-400' : 'bg-stone-200 text-stone-800'
                    }`}>
                      {ORDER_TYPE_LABELS[order.orderType]}
                      {order.tableNumber && ` · ${order.tableNumber}`}
                    </span>
                  </div>

                  {/* Elapsed Timer badge */}
                  <div className="flex items-center gap-1.5 font-mono text-sm font-bold">
                    <Clock className="w-4 h-4" />
                    <span>{elapsed} min</span>
                  </div>
                </div>

                {/* Card Body: Items & Customizations */}
                <div className="p-4 flex-1 space-y-3.5">
                  <div className="flex items-center justify-between text-xs text-stone-500 pb-2 border-b border-stone-100">
                    <span>Cliente: <strong className="text-stone-800">{order.customerName}</strong></span>
                    <span className="font-mono">{formatTimeOnly(order.createdAt)}</span>
                  </div>

                  <div className="space-y-3">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="p-2.5 rounded-xl bg-stone-50 border border-stone-200 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-stone-900 text-sm">
                            <span className="text-amber-600 mr-1.5 font-mono">{item.quantity}x</span>
                            {item.productName}
                          </span>
                        </div>

                        {/* Add-ons */}
                        {item.addOns && item.addOns.length > 0 && (
                          <div className="text-xs font-semibold text-emerald-700 pl-3">
                            + {item.addOns.map(a => a.name).join(', ')}
                          </div>
                        )}

                        {/* Removals */}
                        {item.removedIngredients && item.removedIngredients.length > 0 && (
                          <div className="text-xs font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md inline-block">
                            NÃO COLOCAR: {item.removedIngredients.join(', ')}
                          </div>
                        )}

                        {/* Kitchen Notes */}
                        {item.notes && (
                          <div className="text-xs text-amber-900 bg-amber-100/60 p-1.5 rounded-md font-medium">
                            ⚠️ Obs: {item.notes}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  {order.customerNotes && (
                    <div className="p-2 bg-amber-50 rounded-lg text-xs text-amber-900 font-medium border border-amber-200">
                      Obs Geral: {order.customerNotes}
                    </div>
                  )}
                </div>

                {/* Big Action Buttons */}
                <div className="p-3 bg-stone-50 border-t border-stone-200 flex items-center gap-2">
                  {order.status === 'recebido' || order.status === 'aguardando_confirmacao' ? (
                    <button
                      type="button"
                      onClick={() => updateOrderStatus(order.id, 'confirmado')}
                      className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-2"
                    >
                      <Check className="w-4 h-4" />
                      Aceitar Pedido
                    </button>
                  ) : order.status === 'confirmado' ? (
                    <button
                      type="button"
                      onClick={() => updateOrderStatus(order.id, 'em_preparacao')}
                      className="flex-1 py-3 bg-amber-500 hover:bg-amber-600 text-stone-950 rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-2"
                    >
                      <Flame className="w-4 h-4" />
                      Iniciar Preparo
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => updateOrderStatus(order.id, 'pronto')}
                      className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-2"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      Marcar como Pronto!
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Ready Orders Summary Strip */}
      {readyOrders.length > 0 && (
        <div className="bg-purple-50 border border-purple-200 p-4 rounded-2xl space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-xs uppercase tracking-wider text-purple-900 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-purple-600" />
              Prontos aguardando retirada ou expedição
            </h3>
            <span className="text-xs text-purple-700 font-semibold">{readyOrders.length} prontos</span>
          </div>

          <div className="flex flex-wrap gap-2">
            {readyOrders.map((ro) => (
              <div
                key={ro.id}
                className="bg-white border border-purple-200 px-3 py-2 rounded-xl flex items-center gap-3 shadow-2xs"
              >
                <div>
                  <div className="font-mono font-bold text-xs text-purple-900">
                    Pedido #{ro.orderNumber}
                  </div>
                  <div className="text-[11px] text-stone-600">
                    {ro.customerName} ({ORDER_TYPE_LABELS[ro.orderType]})
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => updateOrderStatus(ro.id, ro.orderType === 'delivery' ? 'saiu_entrega' : 'entregue')}
                  className="px-2.5 py-1 text-[11px] font-bold text-white bg-purple-700 hover:bg-purple-800 rounded-lg transition-colors"
                >
                  {ro.orderType === 'delivery' ? 'Despachar' : 'Entregar'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
