import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type { Supplier } from '../types/index.ts';
import { formatCurrency } from '../utils/formatters.ts';
import {
  Building2,
  Phone,
  Mail,
  FileSpreadsheet,
  AlertTriangle,
  Plus,
  CheckCircle2,
  Package,
  ArrowRight
} from 'lucide-react';

export const SuppliersView: React.FC = () => {
  const { suppliers, inventory, registerInventoryMovement } = useApp();

  // Find low stock items that need replenishment
  const itemsNeedingRestock = inventory.filter(i => i.currentQuantity <= i.minQuantity);

  const [restockedItemId, setRestockedItemId] = useState<string | null>(null);

  const handleQuickRestock = async (itemId: string, suggestedQty: number) => {
    const item = inventory.find(i => i.id === itemId);
    if (!item) return;

    await registerInventoryMovement({
      itemId,
      type: 'compra',
      quantity: suggestedQty,
      reason: `Compra de reposição via fornecedor (${item.supplierName || 'Geral'})`,
      unitCost: item.unitCost
    });

    setRestockedItemId(itemId);
    setTimeout(() => setRestockedItemId(null), 3000);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-900">
            Fornecedores & Sugestão de Compras
          </h1>
          <p className="text-xs sm:text-sm text-stone-500 mt-0.5">
            Gerenciamento de parceiros comerciais e cálculo inteligente de reposição de insumos.
          </p>
        </div>
      </div>

      {/* Intelligent Restock Suggestion Card */}
      <div className="bg-amber-50/60 border border-amber-200 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-amber-900">
            <AlertTriangle className="w-5 h-5 text-amber-600" />
            <h3 className="font-bold text-sm">
              Sugestão Automática de Reposição de Estoque ({itemsNeedingRestock.length} itens)
            </h3>
          </div>
          <span className="text-xs text-amber-800 font-medium">
            Calculado com base no Estoque Mínimo de Segurança
          </span>
        </div>

        {itemsNeedingRestock.length === 0 ? (
          <div className="py-6 text-center text-xs text-emerald-700 flex items-center justify-center gap-2">
            <CheckCircle2 className="w-4 h-4" /> Todos os insumos estão acima do estoque mínimo! Nenhuma compra urgente necessária.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {itemsNeedingRestock.map((item) => {
              const suggestedQty = Math.max(10, item.minQuantity * 2 - item.currentQuantity);
              const totalCost = suggestedQty * item.unitCost;
              const wasRestocked = restockedItemId === item.id;

              return (
                <div
                  key={item.id}
                  className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs space-y-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-bold text-xs text-stone-900">{item.name}</div>
                      <div className="text-[11px] text-stone-500">Fornecedor: {item.supplierName || 'Geral'}</div>
                    </div>
                    <span className="font-mono text-xs font-bold text-rose-600">
                      {item.currentQuantity} / {item.minQuantity} {item.unit}
                    </span>
                  </div>

                  <div className="p-2 bg-stone-50 rounded-lg text-xs font-mono flex justify-between">
                    <span>Comprar: <strong>+{suggestedQty} {item.unit}</strong></span>
                    <span>Custo: <strong>{formatCurrency(totalCost)}</strong></span>
                  </div>

                  <button
                    type="button"
                    disabled={wasRestocked}
                    onClick={() => handleQuickRestock(item.id, suggestedQty)}
                    className="w-full py-2 bg-amber-600 hover:bg-amber-700 disabled:bg-emerald-600 text-white rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                  >
                    {wasRestocked ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Entrada Lançada!</span>
                      </>
                    ) : (
                      <>
                        <Package className="w-3.5 h-3.5" />
                        <span>Receber e Lançar Entrada</span>
                      </>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Suppliers Table */}
      <div className="bg-white rounded-xl border border-stone-200 shadow-2xs p-5 space-y-4">
        <h3 className="font-bold text-sm text-stone-900">Fornecedores Homologados</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {suppliers.map((sup) => (
            <div
              key={sup.id}
              className="p-4 rounded-xl border border-stone-200 bg-stone-50/50 space-y-2.5"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-stone-200 text-stone-700 flex items-center justify-center font-bold">
                  <Building2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-xs text-stone-900">{sup.name}</h4>
                  <div className="text-[10px] text-stone-500">Contato: {sup.contactPerson}</div>
                </div>
              </div>

              <div className="text-[11px] text-stone-600 space-y-1">
                <div className="flex items-center gap-1.5">
                  <Phone className="w-3 h-3 text-stone-400" />
                  <span>{sup.phone}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Mail className="w-3 h-3 text-stone-400" />
                  <span>{sup.email}</span>
                </div>
                {sup.cnpj && (
                  <div className="text-[10px] text-stone-400 font-mono">
                    CNPJ: {sup.cnpj}
                  </div>
                )}
              </div>

              {sup.itemsSupplied && (
                <div className="pt-2 border-t border-stone-200 flex flex-wrap gap-1">
                  {sup.itemsSupplied.map((it, idx) => (
                    <span key={idx} className="text-[10px] bg-white border border-stone-200 text-stone-600 px-1.5 py-0.5 rounded-sm">
                      {it}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
