import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type { Order, OrderStatus, OrderType } from '../types/index.ts';
import {
  formatCurrency,
  formatDateTime,
  formatTimeOnly,
  getElapsedTimeInMinutes,
  ORDER_STATUS_CONFIG,
  ORDER_TYPE_LABELS,
  PAYMENT_METHOD_LABELS
} from '../utils/formatters.ts';
import { ReceiptModal } from '../components/ReceiptModal.tsx';
import {
  Search,
  Filter,
  Kanban,
  List,
  Printer,
  RotateCcw,
  AlertOctagon,
  Clock,
  MapPin,
  Phone,
  User,
  ArrowRight,
  CheckCircle2,
  XCircle,
  Eye,
  MessageSquare,
  ShieldAlert,
  ChevronRight,
  Smartphone
} from 'lucide-react';

export const OrdersView: React.FC = () => {
  const {
    orders,
    updateOrderStatus,
    createOrder,
    settings,
    setTrackingOrderId,
    setCurrentView
  } = useApp();

  const [viewMode, setViewMode] = useState<'kanban' | 'list'>('kanban');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  // Selected Order for Detail Modal
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  // Receipt print
  const [printOrder, setPrintOrder] = useState<Order | null>(null);
  // Cancel Order Modal
  const [orderToCancel, setOrderToCancel] = useState<Order | null>(null);
  const [cancelReason, setCancelReason] = useState('');

  // Filtering
  const filteredOrders = orders.filter((o) => {
    const matchesSearch =
      o.orderNumber.toString().includes(searchTerm) ||
      o.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.customerPhone.includes(searchTerm) ||
      (o.customerAddress?.street || '').toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'all' || o.status === statusFilter;
    const matchesType = typeFilter === 'all' || o.orderType === typeFilter;

    return matchesSearch && matchesStatus && matchesType;
  });

  const kanbanColumns: Array<{
    status: OrderStatus;
    title: string;
    badgeColor: string;
  }> = [
    { status: 'recebido', title: 'Recebidos', badgeColor: 'bg-amber-100 text-amber-800' },
    { status: 'aguardando_confirmacao', title: 'Aguardando Conf.', badgeColor: 'bg-amber-200 text-amber-900' },
    { status: 'confirmado', title: 'Confirmados', badgeColor: 'bg-blue-100 text-blue-800' },
    { status: 'em_preparacao', title: 'Em Preparo', badgeColor: 'bg-orange-100 text-orange-800' },
    { status: 'pronto', title: 'Pronto p/ Retirada', badgeColor: 'bg-purple-100 text-purple-800' },
    { status: 'saiu_entrega', title: 'Saiu p/ Entrega', badgeColor: 'bg-indigo-100 text-indigo-800' },
    { status: 'entregue', title: 'Entregues', badgeColor: 'bg-emerald-100 text-emerald-800' },
  ];

  const getNextStatus = (current: OrderStatus, orderType: OrderType): OrderStatus | null => {
    switch (current) {
      case 'recebido':
      case 'aguardando_confirmacao':
        return 'confirmado';
      case 'confirmado':
        return 'em_preparacao';
      case 'em_preparacao':
        return 'pronto';
      case 'pronto':
        return orderType === 'delivery' ? 'saiu_entrega' : 'entregue';
      case 'saiu_entrega':
        return 'entregue';
      default:
        return null;
    }
  };

  const handleNextStatus = async (order: Order) => {
    const next = getNextStatus(order.status, order.orderType);
    if (next) {
      await updateOrderStatus(order.id, next);
    }
  };

  const handleConfirmCancel = async () => {
    if (!orderToCancel) return;
    await updateOrderStatus(orderToCancel.id, 'cancelado', cancelReason || 'Cancelamento solicitado pela equipe');
    setOrderToCancel(null);
    setCancelReason('');
    if (selectedOrder?.id === orderToCancel.id) {
      setSelectedOrder(null);
    }
  };

  const handleRepeatOrder = async (order: Order) => {
    const repeatData: Partial<Order> = {
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      customerAddress: order.customerAddress,
      orderType: order.orderType,
      tableNumber: order.tableNumber,
      items: order.items.map(i => ({ ...i, id: 'item-' + Date.now() + Math.random().toString(36).substr(2, 4) })),
      subtotal: order.subtotal,
      deliveryFee: order.deliveryFee,
      discount: 0,
      total: order.subtotal + order.deliveryFee,
      paymentMethod: order.paymentMethod,
      paymentStatus: 'pendente',
      customerNotes: order.customerNotes,
      estimatedPrepMinutes: order.estimatedPrepMinutes,
      status: 'recebido'
    };
    const created = await createOrder(repeatData);
    setSelectedOrder(created);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-900">
            Central de Gerenciamento de Pedidos
          </h1>
          <p className="text-xs sm:text-sm text-stone-500 mt-0.5">
            Acompanhe o fluxo ponta a ponta desde o recebimento até a entrega.
          </p>
        </div>

        {/* View toggle */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-stone-100 p-1 rounded-lg border border-stone-200">
            <button
              type="button"
              onClick={() => setViewMode('kanban')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                viewMode === 'kanban'
                  ? 'bg-white text-stone-900 shadow-2xs'
                  : 'text-stone-500 hover:text-stone-900'
              }`}
            >
              <Kanban className="w-4 h-4" />
              <span>Quadro Kanban</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('list')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                viewMode === 'list'
                  ? 'bg-white text-stone-900 shadow-2xs'
                  : 'text-stone-500 hover:text-stone-900'
              }`}
            >
              <List className="w-4 h-4" />
              <span>Lista Detalhada</span>
            </button>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs flex flex-wrap items-center gap-3">
        {/* Search Input */}
        <div className="flex-1 min-w-[240px] relative">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar por nº do pedido, cliente, fone ou endereço..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
          />
        </div>

        {/* Status Filter */}
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-stone-500">Status:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="text-xs bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-2 focus:outline-none"
          >
            <option value="all">Todos os Status ({orders.length})</option>
            <option value="recebido">Recebido</option>
            <option value="aguardando_confirmacao">Aguardando Confirmação</option>
            <option value="confirmado">Confirmado</option>
            <option value="em_preparacao">Em Preparação</option>
            <option value="pronto">Pronto</option>
            <option value="saiu_entrega">Saiu para Entrega</option>
            <option value="entregue">Entregue</option>
            <option value="cancelado">Cancelado</option>
          </select>
        </div>

        {/* Type Filter */}
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-stone-500">Tipo:</span>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="text-xs bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-2 focus:outline-none"
          >
            <option value="all">Todos os Tipos</option>
            <option value="balcao">Balcão</option>
            <option value="mesa">Mesa</option>
            <option value="retirada">Retirada</option>
            <option value="delivery">Delivery</option>
          </select>
        </div>

        {(searchTerm || statusFilter !== 'all' || typeFilter !== 'all') && (
          <button
            type="button"
            onClick={() => {
              setSearchTerm('');
              setStatusFilter('all');
              setTypeFilter('all');
            }}
            className="text-xs text-amber-700 hover:underline px-2 py-1"
          >
            Limpar Filtros
          </button>
        )}
      </div>

      {/* KANBAN VIEW */}
      {viewMode === 'kanban' && (
        <div className="flex gap-4 overflow-x-auto pb-4 items-start min-h-[600px]">
          {kanbanColumns.map((col) => {
            const colOrders = filteredOrders.filter((o) => o.status === col.status);
            return (
              <div
                key={col.status}
                className="w-80 shrink-0 bg-stone-100 rounded-xl p-3 border border-stone-200 flex flex-col max-h-[75vh]"
              >
                {/* Column header */}
                <div className="flex items-center justify-between pb-3 border-b border-stone-200 mb-3 px-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-stone-800">{col.title}</span>
                    <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${col.badgeColor}`}>
                      {colOrders.length}
                    </span>
                  </div>
                </div>

                {/* Cards List */}
                <div className="overflow-y-auto space-y-3 flex-1 pr-1">
                  {colOrders.length === 0 ? (
                    <div className="py-8 text-center text-stone-400 text-xs">
                      Nenhum pedido nesta etapa
                    </div>
                  ) : (
                    colOrders.map((order) => {
                      const elapsed = getElapsedTimeInMinutes(order.createdAt);
                      const isDelayed = elapsed > order.estimatedPrepMinutes && order.status !== 'entregue';
                      const nextStatus = getNextStatus(order.status, order.orderType);

                      return (
                        <div
                          key={order.id}
                          className="bg-white rounded-lg p-3.5 border border-stone-200 shadow-2xs hover:shadow-xs transition-shadow space-y-2.5 relative group"
                        >
                          {/* Card Top: Number, Type, Elapsed Time */}
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-1.5">
                              <span className="font-mono font-bold text-sm text-stone-900">
                                #{order.orderNumber}
                              </span>
                              <span className="text-[10px] uppercase font-semibold text-stone-500 bg-stone-100 px-1.5 py-0.5 rounded-xs">
                                {ORDER_TYPE_LABELS[order.orderType]}
                              </span>
                            </div>

                            <div className="flex items-center gap-1 text-[11px] font-mono">
                              <Clock className={`w-3 h-3 ${isDelayed ? 'text-rose-500' : 'text-stone-400'}`} />
                              <span className={isDelayed ? 'text-rose-600 font-bold' : 'text-stone-500'}>
                                {elapsed} min
                              </span>
                            </div>
                          </div>

                          {/* Customer & Location */}
                          <div>
                            <div className="text-xs font-semibold text-stone-800 truncate">
                              {order.customerName}
                            </div>
                            <div className="text-[11px] text-stone-500 flex items-center gap-1 mt-0.5">
                              <Phone className="w-3 h-3 text-stone-400" />
                              <span>{order.customerPhone}</span>
                            </div>
                            {order.orderType === 'delivery' && order.customerAddress && (
                              <div className="text-[11px] text-stone-500 flex items-start gap-1 mt-0.5 truncate">
                                <MapPin className="w-3 h-3 text-stone-400 shrink-0 mt-0.5" />
                                <span className="truncate">
                                  {order.customerAddress.neighborhood} - {order.customerAddress.street}, {order.customerAddress.number}
                                </span>
                              </div>
                            )}
                            {order.tableNumber && (
                              <div className="text-[11px] font-bold text-amber-800 mt-0.5">
                                {order.tableNumber}
                              </div>
                            )}
                          </div>

                          {/* Items summary */}
                          <div className="pt-2 border-t border-stone-100 text-xs text-stone-700 space-y-1">
                            {order.items.map((item, idx) => (
                              <div key={idx} className="flex justify-between items-start text-[11px]">
                                <span className="font-medium truncate pr-2">
                                  {item.quantity}x {item.productName}
                                </span>
                                <span className="font-mono text-stone-500 shrink-0">
                                  {formatCurrency(item.totalPrice)}
                                </span>
                              </div>
                            ))}
                            {order.items.some(i => i.notes) && (
                              <div className="text-[10px] text-amber-700 italic bg-amber-50 p-1 rounded-sm mt-1">
                                Obs: {order.items.find(i => i.notes)?.notes}
                              </div>
                            )}
                          </div>

                          {/* Total and Payment */}
                          <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                            <span className="font-bold text-stone-900 font-mono">
                              {formatCurrency(order.total)}
                            </span>
                            <span className="text-[10px] text-stone-500 capitalize">
                              {PAYMENT_METHOD_LABELS[order.paymentMethod]} ({order.paymentStatus})
                            </span>
                          </div>

                          {/* Actions Bar */}
                          <div className="pt-2 border-t border-stone-100 flex items-center justify-between gap-1.5">
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => setSelectedOrder(order)}
                                title="Detalhes do pedido"
                                className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-md transition-colors"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setPrintOrder(order)}
                                title="Imprimir cupom"
                                className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-md transition-colors"
                              >
                                <Printer className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setOrderToCancel(order)}
                                title="Cancelar pedido"
                                className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            {nextStatus && (
                              <button
                                type="button"
                                onClick={() => handleNextStatus(order)}
                                className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-md shadow-2xs transition-colors"
                              >
                                <span>Avançar</span>
                                <ChevronRight className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* LIST VIEW */}
      {viewMode === 'list' && (
        <div className="bg-white rounded-xl border border-stone-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4">Pedido #</th>
                  <th className="py-3 px-4">Horário</th>
                  <th className="py-3 px-4">Cliente</th>
                  <th className="py-3 px-4">Tipo</th>
                  <th className="py-3 px-4">Itens</th>
                  <th className="py-3 px-4">Total</th>
                  <th className="py-3 px-4">Pagamento</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredOrders.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-12 text-center text-stone-400">
                      Nenhum pedido encontrado com os filtros aplicados.
                    </td>
                  </tr>
                ) : (
                  filteredOrders.map((order) => {
                    const statusCfg = ORDER_STATUS_CONFIG[order.status];
                    const nextStatus = getNextStatus(order.status, order.orderType);

                    return (
                      <tr key={order.id} className="hover:bg-stone-50/80 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-stone-900">
                          #{order.orderNumber}
                        </td>
                        <td className="py-3 px-4 text-stone-500 font-mono">
                          {formatTimeOnly(order.createdAt)}
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-semibold text-stone-800">{order.customerName}</div>
                          <div className="text-[11px] text-stone-500">{order.customerPhone}</div>
                        </td>
                        <td className="py-3 px-4">
                          <span className="uppercase text-[10px] font-semibold text-stone-600 bg-stone-100 px-2 py-0.5 rounded-sm">
                            {ORDER_TYPE_LABELS[order.orderType]}
                          </span>
                        </td>
                        <td className="py-3 px-4 max-w-[200px]">
                          <div className="truncate text-stone-700">
                            {order.items.map(i => `${i.quantity}x ${i.productName}`).join(', ')}
                          </div>
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-stone-900">
                          {formatCurrency(order.total)}
                        </td>
                        <td className="py-3 px-4">
                          <div className="capitalize text-stone-800">{PAYMENT_METHOD_LABELS[order.paymentMethod]}</div>
                          <span className={`text-[10px] font-semibold ${order.paymentStatus === 'pago' ? 'text-emerald-700' : 'text-amber-700'}`}>
                            {order.paymentStatus.toUpperCase()}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${statusCfg.bg} ${statusCfg.text} ${statusCfg.border}`}>
                            {statusCfg.label}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => setSelectedOrder(order)}
                              title="Visualizar Detalhes"
                              className="p-1.5 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-md"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setPrintOrder(order)}
                              title="Imprimir Cupom"
                              className="p-1.5 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-md"
                            >
                              <Printer className="w-4 h-4" />
                            </button>
                            {nextStatus && (
                              <button
                                type="button"
                                onClick={() => handleNextStatus(order)}
                                className="px-2.5 py-1 text-[11px] font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-md transition-colors"
                              >
                                Avançar
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* DETAIL MODAL */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full flex flex-col max-h-[90vh] overflow-hidden">
            {/* Header */}
            <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
              <div className="flex items-center gap-3">
                <span className="font-mono text-lg font-bold text-stone-900">
                  Pedido #{selectedOrder.orderNumber}
                </span>
                <span className={`px-2.5 py-0.5 text-xs font-bold rounded-full ${ORDER_STATUS_CONFIG[selectedOrder.status].bg} ${ORDER_STATUS_CONFIG[selectedOrder.status].text}`}>
                  {ORDER_STATUS_CONFIG[selectedOrder.status].label}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setSelectedOrder(null)}
                className="text-stone-400 hover:text-stone-700 p-1"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Content */}
            <div className="p-6 overflow-y-auto space-y-6 text-xs">
              {/* Customer & Order Metadata */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-stone-50 rounded-xl border border-stone-200">
                <div className="space-y-1">
                  <div className="text-[11px] font-semibold text-stone-500 uppercase">Dados do Cliente</div>
                  <div className="font-bold text-sm text-stone-900">{selectedOrder.customerName}</div>
                  <div className="text-stone-600">{selectedOrder.customerPhone}</div>
                  <div className="text-stone-500">
                    Atendimento: <strong>{ORDER_TYPE_LABELS[selectedOrder.orderType]}</strong>
                    {selectedOrder.tableNumber && ` (${selectedOrder.tableNumber})`}
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="text-[11px] font-semibold text-stone-500 uppercase">Logística & Pagamento</div>
                  <div>Criado em: <strong>{formatDateTime(selectedOrder.createdAt)}</strong></div>
                  <div>Forma de Pagto: <strong>{PAYMENT_METHOD_LABELS[selectedOrder.paymentMethod]}</strong> ({selectedOrder.paymentStatus})</div>
                  {selectedOrder.courierName && (
                    <div>Entregador: <strong>{selectedOrder.courierName}</strong></div>
                  )}
                  {selectedOrder.customerAddress && (
                    <div className="text-stone-600">
                      Entrega: {selectedOrder.customerAddress.street}, {selectedOrder.customerAddress.number} - {selectedOrder.customerAddress.neighborhood}
                    </div>
                  )}
                </div>
              </div>

              {/* Items List */}
              <div>
                <h4 className="font-bold text-stone-900 text-sm mb-3">Itens do Pedido</h4>
                <div className="border border-stone-200 rounded-lg overflow-hidden divide-y divide-stone-100">
                  {selectedOrder.items.map((item, idx) => (
                    <div key={idx} className="p-3 flex justify-between items-start bg-white">
                      <div className="space-y-1">
                        <div className="font-semibold text-stone-900">
                          {item.quantity}x {item.productName}
                        </div>
                        {item.addOns && item.addOns.length > 0 && (
                          <div className="text-[11px] text-stone-500 pl-3">
                            Adicionais: {item.addOns.map(a => `${a.name} (+${formatCurrency(a.price)})`).join(', ')}
                          </div>
                        )}
                        {item.removedIngredients && item.removedIngredients.length > 0 && (
                          <div className="text-[11px] text-rose-600 pl-3">
                            Remover: {item.removedIngredients.join(', ')}
                          </div>
                        )}
                        {item.notes && (
                          <div className="text-[11px] text-amber-700 italic pl-3">
                            Nota: {item.notes}
                          </div>
                        )}
                      </div>
                      <div className="font-mono font-bold text-stone-900">
                        {formatCurrency(item.totalPrice)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Financial Totals */}
              <div className="p-4 bg-stone-50 rounded-xl space-y-1 text-right border border-stone-200">
                <div className="flex justify-between text-stone-600">
                  <span>Subtotal:</span>
                  <span className="font-mono">{formatCurrency(selectedOrder.subtotal)}</span>
                </div>
                {selectedOrder.deliveryFee > 0 && (
                  <div className="flex justify-between text-stone-600">
                    <span>Taxa de Entrega:</span>
                    <span className="font-mono">{formatCurrency(selectedOrder.deliveryFee)}</span>
                  </div>
                )}
                {selectedOrder.discount > 0 && (
                  <div className="flex justify-between text-rose-600">
                    <span>Desconto ({selectedOrder.couponCode || 'Promo'}):</span>
                    <span className="font-mono">- {formatCurrency(selectedOrder.discount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-base font-bold text-stone-900 pt-2 border-t border-stone-200">
                  <span>Total Final:</span>
                  <span className="font-mono">{formatCurrency(selectedOrder.total)}</span>
                </div>
              </div>

              {/* Status History & Communication Log */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="font-bold text-stone-900 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-stone-500" />
                    Histórico de Etapas
                  </h4>
                  <div className="space-y-2 border-l-2 border-amber-500 pl-3 text-[11px]">
                    {selectedOrder.statusHistory.map((sh, idx) => (
                      <div key={idx} className="space-y-0.5">
                        <div className="font-semibold text-stone-800 capitalize">
                          {ORDER_STATUS_CONFIG[sh.status]?.label || sh.status}
                        </div>
                        <div className="text-stone-400 font-mono">
                          {formatDateTime(sh.timestamp)} · {sh.updatedBy}
                        </div>
                        {sh.note && <div className="text-stone-600 italic">{sh.note}</div>}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-bold text-stone-900 flex items-center gap-1.5">
                    <MessageSquare className="w-4 h-4 text-stone-500" />
                    Mensagens Enviadas ao Cliente
                  </h4>
                  <div className="space-y-2 border-l-2 border-blue-500 pl-3 text-[11px]">
                    {selectedOrder.communicationLog.length === 0 ? (
                      <div className="text-stone-400">Nenhuma mensagem registrada.</div>
                    ) : (
                      selectedOrder.communicationLog.map((log, idx) => (
                        <div key={idx} className="space-y-0.5">
                          <div className="font-medium text-stone-700">"{log.message}"</div>
                          <div className="text-stone-400 font-mono">
                            Canal: {log.channel.toUpperCase()} · {formatDateTime(log.timestamp)}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="p-4 border-t border-stone-200 bg-stone-50 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleRepeatOrder(selectedOrder)}
                  className="px-3 py-2 text-xs font-semibold text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50 transition-colors flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Repetir Pedido
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTrackingOrderId(selectedOrder.id);
                    setCurrentView('order-tracking');
                  }}
                  className="px-3 py-2 text-xs font-semibold text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50 transition-colors flex items-center gap-1.5"
                >
                  <Smartphone className="w-3.5 h-3.5 text-amber-600" />
                  Ver Rastreio do Cliente
                </button>
                <button
                  type="button"
                  onClick={() => setPrintOrder(selectedOrder)}
                  className="px-3 py-2 text-xs font-semibold text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50 transition-colors flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Imprimir Cupom
                </button>
              </div>

              <div className="flex items-center gap-2">
                {selectedOrder.status !== 'cancelado' && (
                  <button
                    type="button"
                    onClick={() => {
                      setOrderToCancel(selectedOrder);
                    }}
                    className="px-3 py-2 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg transition-colors flex items-center gap-1.5"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    Cancelar Pedido
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setSelectedOrder(null)}
                  className="px-4 py-2 text-xs font-semibold text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50 transition-colors"
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CANCEL MODAL */}
      {orderToCancel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center gap-2 text-rose-600">
              <AlertOctagon className="w-6 h-6" />
              <h3 className="font-bold text-base text-stone-900">
                Cancelar Pedido #{orderToCancel.orderNumber}
              </h3>
            </div>
            <p className="text-xs text-stone-600 leading-relaxed">
              O cancelamento irá retornar os insumos reservados/consumidos de volta ao estoque e registrar o log de auditoria com a justificativa.
            </p>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-stone-700">Justificativa do cancelamento:</label>
              <textarea
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                rows={3}
                placeholder="Ex: Desistência do cliente, item em falta, erro no endereço..."
                className="w-full p-2.5 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setOrderToCancel(null)}
                className="px-3 py-2 text-xs font-medium text-stone-600 hover:bg-stone-100 rounded-lg"
              >
                Voltar
              </button>
              <button
                type="button"
                onClick={handleConfirmCancel}
                className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors"
              >
                Confirmar Cancelamento
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PRINT RECEIPT MODAL */}
      <ReceiptModal
        order={printOrder}
        settings={settings}
        onClose={() => setPrintOrder(null)}
      />
    </div>
  );
};
