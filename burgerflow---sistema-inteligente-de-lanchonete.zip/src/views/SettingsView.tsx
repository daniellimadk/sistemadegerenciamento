import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type { RestaurantSettings } from '../types/index.ts';
import {
  Settings,
  Store,
  Phone,
  Clock,
  Volume2,
  Printer,
  MessageSquare,
  RotateCcw,
  CheckCircle2,
  Save,
  Radio,
  Sliders
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const { settings, updateSettings, testSound, resetDemoData } = useApp();

  const [formData, setFormData] = useState<RestaurantSettings>({ ...settings });
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateSettings(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-5xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-900">
            Configurações da Lanchonete & Automações
          </h1>
          <p className="text-xs sm:text-sm text-stone-500 mt-0.5">
            Dados comerciais, mensagens automáticas, alertas sonoros e impressão.
          </p>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg text-xs font-bold">
            <CheckCircle2 className="w-4 h-4" /> Configurações salvas com sucesso!
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Business Data Card */}
        <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 border-b border-stone-100 pb-3">
            <Store className="w-5 h-5 text-amber-600" />
            <h3 className="font-bold text-sm text-stone-900">Dados da Empresa & Atendimento</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="font-semibold text-stone-700">Nome Comercial / Marca:</label>
              <input
                type="text"
                value={formData.restaurantName}
                onChange={(e) => setFormData({ ...formData, restaurantName: e.target.value })}
                className="w-full mt-1 p-2.5 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none"
              />
            </div>
            <div>
              <label className="font-semibold text-stone-700">Razão Social:</label>
              <input
                type="text"
                value={formData.tradeName}
                onChange={(e) => setFormData({ ...formData, tradeName: e.target.value })}
                className="w-full mt-1 p-2.5 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none"
              />
            </div>
            <div>
              <label className="font-semibold text-stone-700">Telefone / Fixo:</label>
              <input
                type="text"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full mt-1 p-2.5 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none"
              />
            </div>
            <div>
              <label className="font-semibold text-stone-700">WhatsApp Comercial (com DDD):</label>
              <input
                type="text"
                value={formData.whatsapp}
                onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                placeholder="5511999998888"
                className="w-full mt-1 p-2.5 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none"
              />
            </div>
            <div>
              <label className="font-semibold text-stone-700">Endereço Completo:</label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="w-full mt-1 p-2.5 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none"
              />
            </div>
            <div>
              <label className="font-semibold text-stone-700">CNPJ:</label>
              <input
                type="text"
                value={formData.cnpj}
                onChange={(e) => setFormData({ ...formData, cnpj: e.target.value })}
                className="w-full mt-1 p-2.5 bg-stone-50 border border-stone-200 rounded-lg font-mono focus:outline-none"
              />
            </div>
          </div>

          {/* Open / Closed Switch */}
          <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
            <div>
              <div className="font-semibold text-xs text-stone-900">Status da Lanchonete:</div>
              <div className="text-[11px] text-stone-500">
                Define se os clientes podem enviar novos pedidos pelo cardápio online
              </div>
            </div>
            <button
              type="button"
              onClick={() => setFormData({ ...formData, isOpen: !formData.isOpen })}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-colors ${
                formData.isOpen
                  ? 'bg-emerald-600 text-white'
                  : 'bg-rose-600 text-white'
              }`}
            >
              {formData.isOpen ? 'ESTABELECIMENTO ABERTO' : 'FECHADO NO MOMENTO'}
            </button>
          </div>
        </div>

        {/* Delivery & Operational Limits Card */}
        <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 border-b border-stone-100 pb-3">
            <Sliders className="w-5 h-5 text-amber-600" />
            <h3 className="font-bold text-sm text-stone-900">Taxas & Regras de Atendimento</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="font-semibold text-stone-700">Taxa Padrão de Entrega (R$):</label>
              <input
                type="number"
                step="0.5"
                value={formData.standardDeliveryFee}
                onChange={(e) => setFormData({ ...formData, standardDeliveryFee: parseFloat(e.target.value) || 0 })}
                className="w-full mt-1 p-2.5 bg-stone-50 border border-stone-200 rounded-lg font-mono"
              />
            </div>
            <div>
              <label className="font-semibold text-stone-700">Frete Grátis a Partir de (R$):</label>
              <input
                type="number"
                step="1"
                value={formData.freeDeliveryThreshold}
                onChange={(e) => setFormData({ ...formData, freeDeliveryThreshold: parseFloat(e.target.value) || 0 })}
                className="w-full mt-1 p-2.5 bg-stone-50 border border-stone-200 rounded-lg font-mono"
              />
            </div>
            <div>
              <label className="font-semibold text-stone-700">Tempo Médio de Preparo (min):</label>
              <input
                type="number"
                value={formData.averagePrepTimeMinutes}
                onChange={(e) => setFormData({ ...formData, averagePrepTimeMinutes: parseInt(e.target.value) || 20 })}
                className="w-full mt-1 p-2.5 bg-stone-50 border border-stone-200 rounded-lg font-mono"
              />
            </div>
          </div>
        </div>

        {/* Automated Customer Messages Templates Card */}
        <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 border-b border-stone-100 pb-3">
            <MessageSquare className="w-5 h-5 text-blue-600" />
            <div>
              <h3 className="font-bold text-sm text-stone-900">
                Modelos de Mensagens Automáticas de Acompanhamento
              </h3>
              <p className="text-[11px] text-stone-500">
                Disparadas em cada etapa no acompanhamento do cliente e notificações.
              </p>
            </div>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="font-semibold text-stone-700">1. Pedido Recebido:</label>
              <input
                type="text"
                value={formData.automatedMessages.recebido}
                onChange={(e) => setFormData({
                  ...formData,
                  automatedMessages: { ...formData.automatedMessages, recebido: e.target.value }
                })}
                className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
              />
            </div>

            <div>
              <label className="font-semibold text-stone-700">2. Pedido Confirmado:</label>
              <input
                type="text"
                value={formData.automatedMessages.confirmado}
                onChange={(e) => setFormData({
                  ...formData,
                  automatedMessages: { ...formData.automatedMessages, confirmado: e.target.value }
                })}
                className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
              />
            </div>

            <div>
              <label className="font-semibold text-stone-700">3. Em Preparação na Cozinha:</label>
              <input
                type="text"
                value={formData.automatedMessages.em_preparacao}
                onChange={(e) => setFormData({
                  ...formData,
                  automatedMessages: { ...formData.automatedMessages, em_preparacao: e.target.value }
                })}
                className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
              />
            </div>

            <div>
              <label className="font-semibold text-stone-700">4. Pedido Pronto (Balcão / Retirada):</label>
              <input
                type="text"
                value={formData.automatedMessages.pronto}
                onChange={(e) => setFormData({
                  ...formData,
                  automatedMessages: { ...formData.automatedMessages, pronto: e.target.value }
                })}
                className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
              />
            </div>

            <div>
              <label className="font-semibold text-stone-700">5. Saiu para Entrega (Delivery):</label>
              <input
                type="text"
                value={formData.automatedMessages.saiu_entrega}
                onChange={(e) => setFormData({
                  ...formData,
                  automatedMessages: { ...formData.automatedMessages, saiu_entrega: e.target.value }
                })}
                className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
              />
            </div>

            <div>
              <label className="font-semibold text-stone-700">6. Pedido Entregue / Concluído:</label>
              <input
                type="text"
                value={formData.automatedMessages.entregue}
                onChange={(e) => setFormData({
                  ...formData,
                  automatedMessages: { ...formData.automatedMessages, entregue: e.target.value }
                })}
                className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
              />
            </div>
          </div>
        </div>

        {/* Audio Alerts & Hardware Card */}
        <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 border-b border-stone-100 pb-3">
            <Volume2 className="w-5 h-5 text-amber-600" />
            <h3 className="font-bold text-sm text-stone-900">Alertas Sonoros & Impressão</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs">
            <div className="space-y-3">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.soundAlertsEnabled}
                  onChange={(e) => setFormData({ ...formData, soundAlertsEnabled: e.target.checked })}
                  className="rounded text-amber-600 focus:ring-amber-500"
                />
                <span className="font-bold text-stone-800">Ativar alerta sonoro ao receber pedidos</span>
              </label>

              <div>
                <label className="font-semibold text-stone-700">Volume do Alarme:</label>
                <div className="flex items-center gap-3 mt-1">
                  <input
                    type="range"
                    min="0.1"
                    max="1.0"
                    step="0.1"
                    value={formData.soundVolume}
                    onChange={(e) => setFormData({ ...formData, soundVolume: parseFloat(e.target.value) })}
                    className="flex-1"
                  />
                  <span className="font-mono text-stone-600 font-bold w-10">
                    {Math.round(formData.soundVolume * 100)}%
                  </span>
                  <button
                    type="button"
                    onClick={testSound}
                    className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-md font-semibold"
                  >
                    Testar Som
                  </button>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <label className="font-semibold text-stone-700">Largura do Cupom Térmico (Impressora):</label>
              <div className="flex gap-4 mt-1">
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="radio"
                    name="printerWidth"
                    checked={formData.printerWidth === '80mm'}
                    onChange={() => setFormData({ ...formData, printerWidth: '80mm' })}
                  />
                  <span className="font-bold">Bobina 80mm (Padrão)</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="radio"
                    name="printerWidth"
                    checked={formData.printerWidth === '58mm'}
                    onChange={() => setFormData({ ...formData, printerWidth: '58mm' })}
                  />
                  <span>Bobina Estreita 58mm</span>
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Submit bar & Reset Demo Button */}
        <div className="flex items-center justify-between pt-2">
          <button
            type="button"
            onClick={() => {
              if (confirm('Deseja realmente restaurar os dados de demonstração originais da lanchonete?')) {
                resetDemoData();
              }
            }}
            className="flex items-center gap-1.5 px-3 py-2 text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg text-xs font-semibold transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restaurar Dados Iniciais de Demonstração</span>
          </button>

          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>Salvar Todas as Configurações</span>
          </button>
        </div>
      </form>
    </div>
  );
};
