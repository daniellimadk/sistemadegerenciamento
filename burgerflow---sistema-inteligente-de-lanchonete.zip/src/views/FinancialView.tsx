import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type { Expense } from '../types/index.ts';
import { formatCurrency, formatDate } from '../utils/formatters.ts';
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Download,
  Plus,
  Trash2,
  CheckCircle2,
  Clock,
  PieChart,
  FileText,
  Calendar,
  AlertCircle
} from 'lucide-react';

export const FinancialView: React.FC = () => {
  const {
    orders,
    expenses,
    products,
    createExpense,
    updateExpense,
    deleteExpense
  } = useApp();

  const [showAddExpenseModal, setShowAddExpenseModal] = useState(false);
  const [expenseForm, setExpenseForm] = useState<Partial<Expense>>({
    description: '',
    category: 'fixa',
    amount: 150.00,
    dueDate: new Date().toISOString().split('T')[0],
    status: 'pendente'
  });

  // Calculate gross sales (excluding canceled)
  const validOrders = orders.filter(o => o.status !== 'cancelado');
  const grossRevenue = validOrders.reduce((acc, o) => acc + o.subtotal + o.deliveryFee, 0);
  const totalDiscounts = validOrders.reduce((acc, o) => acc + o.discount, 0);
  const netRevenue = grossRevenue - totalDiscounts;

  // CMV: Cost of goods sold based on products costPrice
  const totalCmv = validOrders.reduce((acc, order) => {
    let orderCogs = 0;
    for (const item of order.items) {
      const prod = products.find(p => p.id === item.productId);
      if (prod) {
        orderCogs += prod.costPrice * item.quantity;
      } else {
        orderCogs += item.unitPrice * 0.35 * item.quantity;
      }
    }
    return acc + orderCogs;
  }, 0);

  const grossProfit = netRevenue - totalCmv;

  // Expenses totals
  const totalExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);
  const paidExpenses = expenses.filter(e => e.status === 'pago').reduce((acc, e) => acc + e.amount, 0);
  const pendingExpenses = expenses.filter(e => e.status === 'pendente').reduce((acc, e) => acc + e.amount, 0);

  const netOperatingProfit = grossProfit - totalExpenses;

  // Sales by channel
  const channelBreakdown = validOrders.reduce((acc, order) => {
    acc[order.orderType] = (acc[order.orderType] || 0) + order.total;
    return acc;
  }, {} as Record<string, number>);

  const handleExportCSV = () => {
    const rows = [
      ['DRE SIMPLIFICADA - BURGERFLOW'],
      ['Indicador', 'Valor (R$)'],
      ['Faturamento Bruto', grossRevenue.toFixed(2)],
      ['(-) Descontos Concedidos', totalDiscounts.toFixed(2)],
      ['(=) Receita Líquida', netRevenue.toFixed(2)],
      ['(-) Custo dos Insumos (CMV)', totalCmv.toFixed(2)],
      ['(=) Lucro Bruto Operacional', grossProfit.toFixed(2)],
      ['(-) Despesas Operacionais Totais', totalExpenses.toFixed(2)],
      ['(=) Lucro Líquido Realizado', netOperatingProfit.toFixed(2)],
      [],
      ['DETALHAMENTO DE DESPESAS'],
      ['Descrição', 'Categoria', 'Valor (R$)', 'Vencimento', 'Status'],
      ...expenses.map(e => [e.description, e.category, e.amount.toFixed(2), e.dueDate, e.status])
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map(e => e.join(';')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `relatorio_financeiro_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleSaveExpense = async () => {
    if (!expenseForm.description || !expenseForm.amount) return;
    await createExpense(expenseForm);
    setShowAddExpenseModal(false);
    setExpenseForm({
      description: '',
      category: 'fixa',
      amount: 150.00,
      dueDate: new Date().toISOString().split('T')[0],
      status: 'pendente'
    });
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Title & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-900">
            Financeiro, DRE & Contas a Pagar
          </h1>
          <p className="text-xs sm:text-sm text-stone-500 mt-0.5">
            Demonstrativo de resultado real, controle de despesas e lucratividade.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 bg-white border border-stone-300 text-stone-700 hover:bg-stone-50 rounded-lg text-xs font-semibold shadow-2xs transition-colors"
          >
            <Download className="w-4 h-4 text-stone-500" />
            <span>Exportar Relatório CSV</span>
          </button>
          <button
            type="button"
            onClick={() => setShowAddExpenseModal(true)}
            className="flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Lançar Despesa</span>
          </button>
        </div>
      </div>

      {/* Top 3 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
          <span className="text-xs text-stone-500 font-medium">Receita Bruta Apurada</span>
          <div className="text-2xl font-bold text-stone-900 font-mono mt-2">
            {formatCurrency(grossRevenue)}
          </div>
          <div className="text-[11px] text-stone-500 mt-1">
            {validOrders.length} pedidos válidos apurados
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
          <span className="text-xs text-stone-500 font-medium">Despesas Operacionais Totais</span>
          <div className="text-2xl font-bold text-rose-700 font-mono mt-2">
            {formatCurrency(totalExpenses)}
          </div>
          <div className="text-[11px] text-stone-500 mt-1 flex justify-between">
            <span>Pagas: {formatCurrency(paidExpenses)}</span>
            <span className="text-amber-700 font-semibold">Pendentes: {formatCurrency(pendingExpenses)}</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
          <span className="text-xs text-stone-500 font-medium">Lucro Líquido Operacional</span>
          <div className={`text-2xl font-bold font-mono mt-2 ${
            netOperatingProfit >= 0 ? 'text-emerald-700' : 'text-rose-700'
          }`}>
            {formatCurrency(netOperatingProfit)}
          </div>
          <div className="text-[11px] text-stone-500 mt-1">
            Margem Líquida: <strong>{netRevenue > 0 ? Math.round((netOperatingProfit / netRevenue) * 100) : 0}%</strong>
          </div>
        </div>
      </div>

      {/* DRE Simplificada & Channel Breakdown Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* DRE Card (7 cols) */}
        <div className="lg:col-span-7 bg-white p-6 rounded-xl border border-stone-200 shadow-2xs space-y-4">
          <div className="border-b border-stone-100 pb-3 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-stone-900">
                DRE Simplificada (Demonstrativo de Resultado)
              </h3>
              <p className="text-xs text-stone-500">Separando faturamento bruto de custos e lucro apurado</p>
            </div>
            <FileText className="w-5 h-5 text-amber-600" />
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between py-1.5 border-b border-stone-100 text-stone-800">
              <span className="font-sans font-medium">(+) Faturamento Bruto</span>
              <span className="font-bold">{formatCurrency(grossRevenue)}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-stone-100 text-rose-600">
              <span className="font-sans font-medium">(-) Descontos & Promoções</span>
              <span>- {formatCurrency(totalDiscounts)}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-stone-200 text-stone-900 bg-stone-50 px-2 rounded-sm font-bold">
              <span className="font-sans">(=) Receita Líquida</span>
              <span>{formatCurrency(netRevenue)}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-stone-100 text-stone-700">
              <span className="font-sans font-medium">(-) Custo dos Insumos / Ficha Técnica (CMV)</span>
              <span className="text-rose-600">- {formatCurrency(totalCmv)}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-stone-200 text-blue-900 bg-blue-50/60 px-2 rounded-sm font-bold">
              <span className="font-sans">(=) Lucro Bruto da Operação</span>
              <span>{formatCurrency(grossProfit)}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-stone-100 text-stone-700">
              <span className="font-sans font-medium">(-) Despesas Fixas e Variáveis</span>
              <span className="text-rose-600">- {formatCurrency(totalExpenses)}</span>
            </div>
            <div className="flex justify-between py-2 text-sm text-stone-900 bg-emerald-50 border border-emerald-200 px-3 rounded-lg font-bold">
              <span className="font-sans text-emerald-950">(=) Resultado Líquido Final</span>
              <span className="text-emerald-700">{formatCurrency(netOperatingProfit)}</span>
            </div>
          </div>
        </div>

        {/* Channel Breakdown Card (5 cols) */}
        <div className="lg:col-span-5 bg-white p-6 rounded-xl border border-stone-200 shadow-2xs space-y-4">
          <div className="border-b border-stone-100 pb-3">
            <h3 className="font-bold text-sm text-stone-900">Vendas por Canal de Atendimento</h3>
            <p className="text-xs text-stone-500">Participação de Balcão, Mesa, Retirada e Delivery</p>
          </div>

          <div className="space-y-4 pt-2">
            {Object.entries(channelBreakdown).map(([ch, val]) => {
              const pct = grossRevenue > 0 ? Math.round((val / grossRevenue) * 100) : 0;
              return (
                <div key={ch} className="space-y-1">
                  <div className="flex justify-between text-xs font-medium">
                    <span className="text-stone-700 uppercase">{ch}</span>
                    <span className="font-mono text-stone-900 font-bold">
                      {formatCurrency(val)} ({pct}%)
                    </span>
                  </div>
                  <div className="w-full bg-stone-100 h-2.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        ch === 'delivery' ? 'bg-amber-500' : ch === 'mesa' ? 'bg-blue-500' : 'bg-emerald-500'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Expenses Table */}
      <div className="bg-white rounded-xl border border-stone-200 shadow-2xs p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-stone-100 pb-3">
          <h3 className="font-bold text-sm text-stone-900">
            Contas a Pagar & Despesas Lançadas
          </h3>
          <span className="text-xs text-stone-500">{expenses.length} registros</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 font-semibold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-2.5 px-3">Descrição</th>
                <th className="py-2.5 px-3">Categoria</th>
                <th className="py-2.5 px-3">Vencimento</th>
                <th className="py-2.5 px-3">Valor</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {expenses.map((exp) => (
                <tr key={exp.id} className="hover:bg-stone-50/80">
                  <td className="py-2.5 px-3 font-semibold text-stone-900">
                    {exp.description}
                  </td>
                  <td className="py-2.5 px-3 text-stone-600 capitalize">
                    {exp.category}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-stone-500">
                    {formatDate(exp.dueDate)}
                  </td>
                  <td className="py-2.5 px-3 font-mono font-bold text-stone-900">
                    {formatCurrency(exp.amount)}
                  </td>
                  <td className="py-2.5 px-3">
                    <button
                      type="button"
                      onClick={() => updateExpense(exp.id, { status: exp.status === 'pago' ? 'pendente' : 'pago' })}
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold border transition-colors ${
                        exp.status === 'pago'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-amber-50 text-amber-700 border-amber-200'
                      }`}
                    >
                      {exp.status.toUpperCase()}
                    </button>
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <button
                      type="button"
                      onClick={() => deleteExpense(exp.id)}
                      className="p-1 text-stone-400 hover:text-rose-600 rounded-md"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD EXPENSE MODAL */}
      {showAddExpenseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 space-y-4">
            <h3 className="font-bold text-base text-stone-900">
              Lançar Nova Despesa
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-stone-700">Descrição:</label>
                <input
                  type="text"
                  value={expenseForm.description}
                  onChange={(e) => setExpenseForm({ ...expenseForm, description: e.target.value })}
                  placeholder="Ex: Aluguel do Ponto Comercial"
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700">Categoria:</label>
                <select
                  value={expenseForm.category}
                  onChange={(e) => setExpenseForm({ ...expenseForm, category: e.target.value as any })}
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
                >
                  <option value="fixa">Despesa Fixa (Aluguel, Luz, Água, Gás)</option>
                  <option value="variavel">Despesa Variável</option>
                  <option value="ingredientes">Compra de Ingredientes</option>
                  <option value="taxas">Taxas de Cartão / Meios</option>
                  <option value="pessoal">Pessoal / Funcionários</option>
                  <option value="outros">Outros</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700">Valor (R$):</label>
                  <input
                    type="number"
                    step="1"
                    value={expenseForm.amount}
                    onChange={(e) => setExpenseForm({ ...expenseForm, amount: parseFloat(e.target.value) || 0 })}
                    className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="font-semibold text-stone-700">Data de Vencimento:</label>
                  <input
                    type="date"
                    value={expenseForm.dueDate}
                    onChange={(e) => setExpenseForm({ ...expenseForm, dueDate: e.target.value })}
                    className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-stone-700">Situação:</label>
                <div className="flex gap-4 mt-1">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      checked={expenseForm.status === 'pendente'}
                      onChange={() => setExpenseForm({ ...expenseForm, status: 'pendente' })}
                    />
                    <span>Pendente</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      checked={expenseForm.status === 'pago'}
                      onChange={() => setExpenseForm({ ...expenseForm, status: 'pago' })}
                    />
                    <span>Já Pago</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setShowAddExpenseModal(false)}
                className="px-3 py-2 text-xs font-medium text-stone-600 hover:bg-stone-100 rounded-lg"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSaveExpense}
                className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg"
              >
                Salvar Despesa
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
