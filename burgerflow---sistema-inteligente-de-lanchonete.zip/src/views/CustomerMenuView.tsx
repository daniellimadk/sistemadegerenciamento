import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type { Product, OrderItem, OrderType, PaymentMethod, Order } from '../types/index.ts';
import { formatCurrency, PAYMENT_METHOD_LABELS } from '../utils/formatters.ts';
import {
  ShoppingBag,
  Clock,
  MapPin,
  Search,
  Plus,
  Minus,
  CheckCircle2,
  Sparkles,
  Phone,
  QrCode,
  Banknote,
  CreditCard,
  X,
  Truck,
  ArrowRight,
  Ticket,
  ChevronRight,
  ArrowLeft
} from 'lucide-react';

export const CustomerMenuView: React.FC = () => {
  const {
    products,
    categories,
    settings,
    coupons,
    createOrder,
    setTrackingOrderId,
    setCurrentView
  } = useApp();

  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState<string>('all');

  // Customer Cart
  const [cart, setCart] = useState<OrderItem[]>([]);
  const [showCartDrawer, setShowCartDrawer] = useState(false);
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);

  // Customization modal
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [modalQuantity, setModalQuantity] = useState(1);
  const [chosenAddons, setChosenAddons] = useState<Array<{ id: string; name: string; price: number }>>([]);
  const [chosenRemovals, setChosenRemovals] = useState<string[]>([]);
  const [customNotes, setCustomNotes] = useState('');

  // Checkout Form
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [orderType, setOrderType] = useState<OrderType>('delivery');
  const [street, setStreet] = useState('');
  const [number, setNumber] = useState('');
  const [neighborhood, setNeighborhood] = useState(settings.deliveryNeighborhoods?.[0]?.name || 'Consolação');
  const [complement, setComplement] = useState('');
  const [reference, setReference] = useState('');
  const [tableNumber, setTableNumber] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('pix');
  const [cashChangeFor, setCashChangeFor] = useState('');
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{ code: string; discount: number } | null>(null);
  const [couponError, setCouponError] = useState('');
  const [orderNotes, setOrderNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Filter products
  const filteredProducts = products.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.description.toLowerCase().includes(search.toLowerCase());
    const matchesCat = selectedCat === 'all' || p.categoryId === selectedCat;
    return matchesSearch && matchesCat;
  });

  // Financial calculations
  const subtotal = cart.reduce((acc, i) => acc + i.totalPrice, 0);
  
  // Delivery fee based on selected neighborhood
  const selectedNeighborhoodFee = settings.deliveryNeighborhoods?.find(n => n.name === neighborhood)?.fee ?? settings.standardDeliveryFee;
  const isFreeDelivery = subtotal >= settings.freeDeliveryThreshold;
  const deliveryFee = orderType === 'delivery' ? (isFreeDelivery ? 0 : selectedNeighborhoodFee) : 0;
  
  const discountAmount = appliedCoupon ? appliedCoupon.discount : 0;
  const finalTotal = Math.max(0, subtotal + deliveryFee - discountAmount);

  const totalItemsCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  // Open item customization
  const handleOpenProduct = (product: Product) => {
    setSelectedProduct(product);
    setModalQuantity(1);
    setChosenAddons([]);
    setChosenRemovals([]);
    setCustomNotes('');
  };

  const handleAddToCart = () => {
    if (!selectedProduct) return;
    const addOnTotal = chosenAddons.reduce((acc, a) => acc + a.price, 0);
    const unitPrice = selectedProduct.price + addOnTotal;

    const newItem: OrderItem = {
      id: 'item-' + Date.now() + Math.random().toString(36).substring(2, 5),
      productId: selectedProduct.id,
      productName: selectedProduct.name,
      quantity: modalQuantity,
      unitPrice,
      addOns: chosenAddons,
      removedIngredients: chosenRemovals,
      notes: customNotes,
      totalPrice: unitPrice * modalQuantity
    };

    setCart([...cart, newItem]);
    setSelectedProduct(null);
  };

  const handleApplyCoupon = () => {
    setCouponError('');
    const coupon = coupons.find(c => c.code.toUpperCase() === couponCode.trim().toUpperCase() && c.active);
    if (!coupon) {
      setCouponError('Cupom inválido ou expirado.');
      return;
    }
    if (subtotal < coupon.minOrderValue) {
      setCouponError(`Pedido mínimo para este cupom é ${formatCurrency(coupon.minOrderValue)}.`);
      return;
    }

    let discount = 0;
    if (coupon.discountType === 'fixed') {
      discount = coupon.value;
    } else {
      discount = (subtotal * coupon.value) / 100;
    }

    setAppliedCoupon({ code: coupon.code, discount });
  };

  const handleSubmitOrder = async () => {
    if (!customerName || !customerPhone) {
      alert('Por favor, informe seu nome e WhatsApp para contato.');
      return;
    }
    if (orderType === 'delivery' && (!street || !number || !neighborhood)) {
      alert('Por favor, preencha o endereço completo de entrega.');
      return;
    }

    setSubmitting(true);
    try {
      const orderPayload: Partial<Order> = {
        customerName,
        customerPhone,
        customerAddress: orderType === 'delivery' ? {
          street,
          number,
          neighborhood,
          complement,
          reference,
          city: settings.city
        } : undefined,
        orderType,
        tableNumber: orderType === 'mesa' ? tableNumber : undefined,
        items: cart,
        subtotal,
        deliveryFee,
        discount: discountAmount,
        couponCode: appliedCoupon?.code,
        total: finalTotal,
        paymentMethod,
        paymentStatus: paymentMethod === 'pix' ? 'pago' : 'pendente',
        changeFor: paymentMethod === 'dinheiro' && cashChangeFor ? parseFloat(cashChangeFor) : undefined,
        customerNotes: orderNotes,
        estimatedPrepMinutes: settings.averagePrepTimeMinutes,
        status: settings.autoAcceptOrders ? 'confirmado' : 'recebido'
      };

      const created = await createOrder(orderPayload);
      setCart([]);
      setShowCheckoutModal(false);
      setShowCartDrawer(false);
      setTrackingOrderId(created.id);
      setCurrentView('order-tracking');
    } catch (e) {
      alert('Ocorreu um erro ao enviar seu pedido. Tente novamente.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-stone-50 pb-28">
      {/* Client Top Header Bar */}
      <header className="bg-white border-b border-stone-200 sticky top-0 z-30 shadow-2xs">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setCurrentView('dashboard')}
              className="text-stone-500 hover:text-stone-900 flex items-center gap-1 text-xs font-semibold py-1 px-2 rounded-lg hover:bg-stone-100"
              title="Voltar ao Painel Administrativo"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Painel Admin</span>
            </button>
            <div className="h-4 w-px bg-stone-200 hidden sm:block" />
            <div className="flex items-center gap-2">
              <span className="text-xl">🍔</span>
              <span className="font-extrabold text-base tracking-tight text-stone-900">
                {settings.restaurantName}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-1.5 text-xs text-stone-600">
              <Clock className="w-3.5 h-3.5 text-amber-600" />
              <span>{settings.openingHoursDescription}</span>
            </div>

            <button
              type="button"
              onClick={() => setShowCartDrawer(true)}
              className="relative flex items-center gap-2 px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Carrinho</span>
              {totalItemsCount > 0 && (
                <span className="bg-white text-amber-800 text-[10px] font-black px-1.5 py-0.2 rounded-full">
                  {totalItemsCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Hero Banner */}
      <div className="max-w-5xl mx-auto px-4 pt-4">
        <div className="relative rounded-2xl overflow-hidden h-52 sm:h-64 shadow-md">
          <img
            src="/src/assets/images/lanchonete_hero_banner_1791633574513.jpg"
            alt={settings.restaurantName}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-stone-950/40 to-transparent flex flex-col justify-end p-6 text-white">
            <div className="flex items-center gap-2 mb-1.5">
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                settings.isOpen ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'
              }`}>
                {settings.isOpen ? 'ABERTO AGORA' : 'FECHADO'}
              </span>
              <span className="text-xs text-stone-300">· {settings.averagePrepTimeMinutes}–{settings.averagePrepTimeMinutes + 15} min</span>
              <span className="text-xs text-stone-300">· Frete grátis acima de {formatCurrency(settings.freeDeliveryThreshold)}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Burgers & Petiscos Artesanais
            </h1>
            <p className="text-xs sm:text-sm text-stone-200 mt-1 max-w-xl">
              Blends bovinos nobres grelhados na brasa, pães selados na manteiga e receitas exclusivas feitas na hora para você.
            </p>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <main className="max-w-5xl mx-auto px-4 mt-6 space-y-6">
        {/* Search bar & Category chips */}
        <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="O que você deseja saborear hoje? Ex: Smash, batata, shake..."
              className="w-full pl-9 pr-4 py-2.5 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
            />
          </div>

          <div className="flex gap-2 overflow-x-auto pb-1">
            <button
              type="button"
              onClick={() => setSelectedCat('all')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCat === 'all'
                  ? 'bg-amber-600 text-white shadow-2xs'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              Todos os Itens
            </button>
            {categories.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setSelectedCat(c.id)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedCat === c.id
                    ? 'bg-amber-600 text-white shadow-2xs'
                    : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                }`}
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>

        {/* Catalog Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              onClick={() => product.available && handleOpenProduct(product)}
              className={`bg-white rounded-2xl border border-stone-200 shadow-2xs overflow-hidden transition-all flex flex-col justify-between ${
                product.available
                  ? 'hover:shadow-md hover:border-amber-300 cursor-pointer'
                  : 'opacity-60 cursor-not-allowed'
              }`}
            >
              <div>
                <div className="relative h-44 bg-stone-100 overflow-hidden">
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
                    referrerPolicy="no-referrer"
                  />
                  {product.featured && (
                    <span className="absolute top-2.5 left-2.5 bg-amber-500 text-stone-950 font-bold text-[10px] px-2 py-0.5 rounded-md flex items-center gap-1 shadow-xs">
                      <Sparkles className="w-3 h-3" /> MAIS PEDIDO
                    </span>
                  )}
                  {!product.available && (
                    <div className="absolute inset-0 bg-stone-950/70 flex items-center justify-center text-white font-bold text-xs uppercase tracking-wider">
                      Esgotado Hoje
                    </div>
                  )}
                </div>

                <div className="p-4 space-y-2">
                  <h3 className="font-bold text-stone-900 text-sm leading-snug">
                    {product.name}
                  </h3>
                  <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed">
                    {product.description}
                  </p>
                </div>
              </div>

              <div className="p-4 pt-0 flex items-center justify-between border-t border-stone-100 mt-2">
                <span className="font-mono font-bold text-base text-stone-900">
                  {formatCurrency(product.price)}
                </span>
                <button
                  type="button"
                  disabled={!product.available}
                  className="px-3 py-1.5 bg-amber-50 text-amber-700 hover:bg-amber-600 hover:text-white rounded-xl text-xs font-bold border border-amber-200 transition-colors flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Pedir</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Floating Cart Button on mobile */}
      {totalItemsCount > 0 && !showCartDrawer && !showCheckoutModal && (
        <div className="fixed bottom-4 inset-x-4 max-w-md mx-auto z-40">
          <button
            type="button"
            onClick={() => setShowCartDrawer(true)}
            className="w-full py-3.5 px-5 bg-amber-600 hover:bg-amber-700 text-white rounded-2xl shadow-xl font-bold text-sm flex items-center justify-between transition-transform active:scale-98"
          >
            <div className="flex items-center gap-2">
              <span className="bg-stone-900 text-white text-xs px-2 py-0.5 rounded-full">
                {totalItemsCount}
              </span>
              <span>Ver Carrinho de Compras</span>
            </div>
            <span className="font-mono text-base">{formatCurrency(subtotal)}</span>
          </button>
        </div>
      )}

      {/* PRODUCT CUSTOMIZATION MODAL */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-hidden flex flex-col">
            <div className="relative h-48 bg-stone-100 shrink-0">
              <img
                src={selectedProduct.imageUrl}
                alt={selectedProduct.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <button
                type="button"
                onClick={() => setSelectedProduct(null)}
                className="absolute top-3 right-3 p-1.5 bg-black/60 text-white rounded-full hover:bg-black/80"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-xs">
              <div>
                <h3 className="font-bold text-base text-stone-900">{selectedProduct.name}</h3>
                <p className="text-stone-500 mt-1 leading-relaxed">{selectedProduct.description}</p>
                <div className="font-mono font-bold text-base text-amber-600 mt-1">
                  {formatCurrency(selectedProduct.price)}
                </div>
              </div>

              {/* Addons */}
              {selectedProduct.addOns && selectedProduct.addOns.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-stone-100">
                  <label className="font-bold text-stone-900 text-xs">Deseja Adicionais?</label>
                  <div className="space-y-1.5">
                    {selectedProduct.addOns.map((add) => {
                      const isChecked = chosenAddons.some(a => a.id === add.id);
                      return (
                        <button
                          key={add.id}
                          type="button"
                          onClick={() => {
                            if (isChecked) {
                              setChosenAddons(chosenAddons.filter(a => a.id !== add.id));
                            } else {
                              setChosenAddons([...chosenAddons, add]);
                            }
                          }}
                          className={`w-full p-2.5 rounded-xl border text-xs flex items-center justify-between transition-colors ${
                            isChecked
                              ? 'border-amber-600 bg-amber-50 text-amber-950 font-bold'
                              : 'border-stone-200 bg-stone-50/50 text-stone-700'
                          }`}
                        >
                          <span>{add.name}</span>
                          <span className="font-mono text-stone-600">+{formatCurrency(add.price)}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Removals */}
              {selectedProduct.removableIngredients && selectedProduct.removableIngredients.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-stone-100">
                  <label className="font-bold text-stone-900 text-xs">Remover Algum Ingrediente?</label>
                  <div className="flex flex-wrap gap-2">
                    {selectedProduct.removableIngredients.map((ing) => {
                      const isRemoved = chosenRemovals.includes(ing);
                      return (
                        <button
                          key={ing}
                          type="button"
                          onClick={() => {
                            if (isRemoved) {
                              setChosenRemovals(chosenRemovals.filter(r => r !== ing));
                            } else {
                              setChosenRemovals([...chosenRemovals, ing]);
                            }
                          }}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${
                            isRemoved
                              ? 'bg-rose-50 border-rose-300 text-rose-700 line-through'
                              : 'bg-stone-50 border-stone-200 text-stone-700'
                          }`}
                        >
                          Sem {ing}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Notes */}
              <div className="space-y-1 pt-2 border-t border-stone-100">
                <label className="font-bold text-stone-900 text-xs">Observações do Item:</label>
                <input
                  type="text"
                  value={customNotes}
                  onChange={(e) => setCustomNotes(e.target.value)}
                  placeholder="Ex: Ponto da carne, molho à parte..."
                  className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none"
                />
              </div>
            </div>

            {/* Modal Bottom Add Bar */}
            <div className="p-4 bg-stone-50 border-t border-stone-200 flex items-center justify-between gap-4">
              <div className="flex items-center border border-stone-300 rounded-xl bg-white shadow-2xs">
                <button
                  type="button"
                  onClick={() => setModalQuantity(Math.max(1, modalQuantity - 1))}
                  className="p-2 text-stone-600 hover:text-stone-900"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="px-3 font-mono font-bold text-sm">{modalQuantity}</span>
                <button
                  type="button"
                  onClick={() => setModalQuantity(modalQuantity + 1)}
                  className="p-2 text-stone-600 hover:text-stone-900"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              <button
                type="button"
                onClick={handleAddToCart}
                className="flex-1 py-3 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-2"
              >
                <span>Adicionar ao Carrinho</span>
                <span className="font-mono">
                  ({formatCurrency((selectedProduct.price + chosenAddons.reduce((a, b) => a + b.price, 0)) * modalQuantity)})
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CART DRAWER / SIDEBAR */}
      {showCartDrawer && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-md h-full flex flex-col shadow-2xl">
            <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-amber-600" />
                <h3 className="font-bold text-sm text-stone-900">Seu Carrinho de Compras</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowCartDrawer(false)}
                className="text-stone-400 hover:text-stone-700 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3 divide-y divide-stone-100">
              {cart.length === 0 ? (
                <div className="py-20 text-center text-xs text-stone-400 space-y-2">
                  <ShoppingBag className="w-8 h-8 mx-auto text-stone-300" />
                  <p>Seu carrinho está vazio.</p>
                </div>
              ) : (
                cart.map((item, idx) => (
                  <div key={idx} className="pt-3 first:pt-0 flex justify-between items-start text-xs">
                    <div className="space-y-0.5 flex-1 pr-2">
                      <div className="font-bold text-stone-900">
                        {item.quantity}x {item.productName}
                      </div>
                      {item.addOns && item.addOns.length > 0 && (
                        <div className="text-[11px] text-stone-500 pl-2">
                          + {item.addOns.map(a => a.name).join(', ')}
                        </div>
                      )}
                      {item.removedIngredients && item.removedIngredients.length > 0 && (
                        <div className="text-[11px] text-rose-600 pl-2">
                          Sem: {item.removedIngredients.join(', ')}
                        </div>
                      )}
                      {item.notes && (
                        <div className="text-[11px] text-amber-700 italic pl-2">
                          Obs: {item.notes}
                        </div>
                      )}
                    </div>

                    <div className="flex flex-col items-end gap-1">
                      <span className="font-mono font-bold text-stone-900">
                        {formatCurrency(item.totalPrice)}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          const updated = [...cart];
                          updated.splice(idx, 1);
                          setCart(updated);
                        }}
                        className="text-[11px] text-rose-600 hover:underline"
                      >
                        Remover
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Bottom summary and proceed to checkout */}
            {cart.length > 0 && (
              <div className="p-4 bg-stone-50 border-t border-stone-200 space-y-3">
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between text-stone-600">
                    <span>Subtotal:</span>
                    <span className="font-mono font-medium">{formatCurrency(subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-base font-bold text-stone-900 pt-1 border-t border-stone-200">
                    <span>Total Estimado:</span>
                    <span className="font-mono text-amber-600">{formatCurrency(subtotal)}</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setShowCartDrawer(false);
                    setShowCheckoutModal(true);
                  }}
                  className="w-full py-3.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-2"
                >
                  <span>Avançar para o Checkout</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* CHECKOUT MODAL */}
      {showCheckoutModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[92vh] overflow-hidden flex flex-col">
            <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
              <h3 className="font-bold text-sm text-stone-900">Finalizar e Confirmar Pedido</h3>
              <button
                type="button"
                onClick={() => setShowCheckoutModal(false)}
                className="text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-xs">
              {/* Type selector */}
              <div className="grid grid-cols-2 gap-2 bg-stone-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setOrderType('delivery')}
                  className={`py-2 rounded-lg font-bold text-xs flex items-center justify-center gap-2 transition-colors ${
                    orderType === 'delivery' ? 'bg-white text-stone-900 shadow-2xs' : 'text-stone-600'
                  }`}
                >
                  <Truck className="w-4 h-4 text-amber-600" />
                  <span>Entrega Delivery</span>
                </button>
                <button
                  type="button"
                  onClick={() => setOrderType('retirada')}
                  className={`py-2 rounded-lg font-bold text-xs flex items-center justify-center gap-2 transition-colors ${
                    orderType === 'retirada' ? 'bg-white text-stone-900 shadow-2xs' : 'text-stone-600'
                  }`}
                >
                  <ShoppingBag className="w-4 h-4 text-amber-600" />
                  <span>Retirar no Balcão</span>
                </button>
              </div>

              {/* Customer contact */}
              <div className="space-y-2">
                <label className="font-bold text-stone-900">Seus Dados de Contato:</label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Seu nome completo"
                    className="p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none"
                  />
                  <input
                    type="text"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="WhatsApp (ex: 11 99999-8888)"
                    className="p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none"
                  />
                </div>
              </div>

              {/* Delivery Address fields */}
              {orderType === 'delivery' && (
                <div className="space-y-2 pt-2 border-t border-stone-100">
                  <label className="font-bold text-stone-900">Endereço de Entrega:</label>
                  <div className="grid grid-cols-3 gap-2">
                    <input
                      type="text"
                      value={street}
                      onChange={(e) => setStreet(e.target.value)}
                      placeholder="Rua / Avenida"
                      className="col-span-2 p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none"
                    />
                    <input
                      type="text"
                      value={number}
                      onChange={(e) => setNumber(e.target.value)}
                      placeholder="Nº"
                      className="p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <select
                      value={neighborhood}
                      onChange={(e) => setNeighborhood(e.target.value)}
                      className="p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none"
                    >
                      {(settings.deliveryNeighborhoods || []).map((n) => (
                        <option key={n.name} value={n.name}>
                          {n.name} (+{formatCurrency(n.fee)})
                        </option>
                      ))}
                    </select>
                    <input
                      type="text"
                      value={complement}
                      onChange={(e) => setComplement(e.target.value)}
                      placeholder="Apto / Bloco (opcional)"
                      className="p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none"
                    />
                  </div>
                </div>
              )}

              {/* Coupon input */}
              <div className="space-y-1.5 pt-2 border-t border-stone-100">
                <label className="font-bold text-stone-900">Cupom de Desconto:</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    placeholder="Ex: BEMVINDO10"
                    className="flex-1 p-2 bg-stone-50 border border-stone-200 rounded-xl uppercase font-mono"
                  />
                  <button
                    type="button"
                    onClick={handleApplyCoupon}
                    className="px-4 py-2 bg-stone-900 text-white rounded-xl font-bold"
                  >
                    Aplicar
                  </button>
                </div>
                {appliedCoupon && (
                  <div className="text-[11px] text-emerald-700 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Cupom {appliedCoupon.code} aplicado com sucesso! (-{formatCurrency(appliedCoupon.discount)})
                  </div>
                )}
                {couponError && (
                  <div className="text-[11px] text-rose-600 font-medium">
                    {couponError}
                  </div>
                )}
              </div>

              {/* Payment Method */}
              <div className="space-y-2 pt-2 border-t border-stone-100">
                <label className="font-bold text-stone-900">Forma de Pagamento:</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('pix')}
                    className={`p-2.5 rounded-xl border text-center flex flex-col items-center gap-1 transition-colors ${
                      paymentMethod === 'pix'
                        ? 'border-amber-600 bg-amber-50 text-amber-900 font-bold'
                        : 'border-stone-200 bg-stone-50/50'
                    }`}
                  >
                    <QrCode className="w-4 h-4 text-emerald-600" />
                    <span>Pix Online</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('cartao_credito')}
                    className={`p-2.5 rounded-xl border text-center flex flex-col items-center gap-1 transition-colors ${
                      paymentMethod.includes('cartao')
                        ? 'border-amber-600 bg-amber-50 text-amber-900 font-bold'
                        : 'border-stone-200 bg-stone-50/50'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 text-blue-600" />
                    <span>Cartão Maquininha</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('dinheiro')}
                    className={`p-2.5 rounded-xl border text-center flex flex-col items-center gap-1 transition-colors ${
                      paymentMethod === 'dinheiro'
                        ? 'border-amber-600 bg-amber-50 text-amber-900 font-bold'
                        : 'border-stone-200 bg-stone-50/50'
                    }`}
                  >
                    <Banknote className="w-4 h-4 text-amber-600" />
                    <span>Dinheiro</span>
                  </button>
                </div>

                {paymentMethod === 'dinheiro' && (
                  <div className="p-3 bg-stone-50 rounded-xl space-y-1">
                    <label className="text-[11px] text-stone-600">Precisa de troco para quanto?</label>
                    <input
                      type="number"
                      value={cashChangeFor}
                      onChange={(e) => setCashChangeFor(e.target.value)}
                      placeholder="Ex: 50,00 ou 100,00"
                      className="w-full p-2 bg-white border border-stone-200 rounded-lg font-mono"
                    />
                  </div>
                )}
              </div>

              {/* Order Final Summary */}
              <div className="p-3.5 bg-stone-100 rounded-xl space-y-1.5 font-mono text-xs">
                <div className="flex justify-between text-stone-600 font-sans">
                  <span>Itens ({totalItemsCount}):</span>
                  <span>{formatCurrency(subtotal)}</span>
                </div>
                {orderType === 'delivery' && (
                  <div className="flex justify-between text-stone-600 font-sans">
                    <span>Taxa de Entrega:</span>
                    <span>{isFreeDelivery ? 'GRÁTIS' : formatCurrency(deliveryFee)}</span>
                  </div>
                )}
                {discountAmount > 0 && (
                  <div className="flex justify-between text-rose-600 font-sans">
                    <span>Desconto do Cupom:</span>
                    <span>- {formatCurrency(discountAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-sm text-stone-900 pt-1 border-t border-stone-200 font-sans">
                  <span>Total Final:</span>
                  <span className="font-mono text-amber-600 text-base">{formatCurrency(finalTotal)}</span>
                </div>
              </div>
            </div>

            <div className="p-4 bg-stone-50 border-t border-stone-200 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => setShowCheckoutModal(false)}
                className="px-4 py-2.5 text-xs font-semibold text-stone-600 hover:bg-stone-200 rounded-xl"
              >
                Voltar
              </button>
              <button
                type="button"
                disabled={submitting}
                onClick={handleSubmitOrder}
                className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Confirmar e Fazer Pedido</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
