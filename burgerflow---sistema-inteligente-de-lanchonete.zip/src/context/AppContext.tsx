import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type {
  Order,
  Product,
  Category,
  InventoryItem,
  InventoryMovement,
  CashRegister,
  CashMovement,
  Expense,
  Customer,
  Coupon,
  Courier,
  Supplier,
  UserAccount,
  RestaurantSettings,
  SystemNotification,
  SystemAuditLog,
  OrderStatus,
  OrderType,
  PaymentMethod
} from '../types/index.ts';
import { playOrderAlertSound, playReadyAlertSound, playWarningSound } from '../utils/audioAlert.ts';

export type AppView =
  | 'dashboard'
  | 'orders'
  | 'kitchen'
  | 'pos'
  | 'cash-register'
  | 'inventory'
  | 'products'
  | 'financial'
  | 'delivery'
  | 'customers'
  | 'suppliers'
  | 'settings'
  | 'customer-menu'
  | 'order-tracking';

interface AppContextType {
  // Navigation & UI
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  currentUser: UserAccount;
  setCurrentUser: (user: UserAccount) => void;
  allUsers: UserAccount[];
  trackingOrderId: string | null;
  setTrackingOrderId: (id: string | null) => void;
  
  // Data
  categories: Category[];
  products: Product[];
  inventory: InventoryItem[];
  orders: Order[];
  cashRegister: CashRegister | null;
  cashMovements: CashMovement[];
  expenses: Expense[];
  customers: Customer[];
  coupons: Coupon[];
  couriers: Courier[];
  suppliers: Supplier[];
  settings: RestaurantSettings;
  notifications: SystemNotification[];
  auditLogs: SystemAuditLog[];
  unreadNotificationsCount: number;
  loading: boolean;
  connectedSSE: boolean;

  // Actions
  createOrder: (orderData: Partial<Order>) => Promise<Order>;
  updateOrderStatus: (orderId: string, status: OrderStatus, reason?: string, courierId?: string, courierName?: string) => Promise<void>;
  createProduct: (product: Partial<Product>) => Promise<void>;
  updateProduct: (id: string, product: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  registerInventoryMovement: (data: { itemId: string; type: string; quantity: number; reason: string; unitCost?: number }) => Promise<void>;
  updateInventoryItem: (id: string, data: Partial<InventoryItem>) => Promise<void>;
  createInventoryItem: (data: Partial<InventoryItem>) => Promise<void>;
  openCashRegister: (initialCash: number, notes?: string) => Promise<void>;
  closeCashRegister: (finalCashCounted: number, notes?: string) => Promise<void>;
  addCashMovement: (type: 'sangria' | 'suprimento', amount: number, reason: string) => Promise<void>;
  createExpense: (expense: Partial<Expense>) => Promise<void>;
  updateExpense: (id: string, expense: Partial<Expense>) => Promise<void>;
  deleteExpense: (id: string) => Promise<void>;
  updateSettings: (newSettings: Partial<RestaurantSettings>) => Promise<void>;
  markNotificationAsRead: (id: string) => Promise<void>;
  markAllNotificationsAsRead: () => Promise<void>;
  resetDemoData: () => Promise<void>;
  refreshData: () => Promise<void>;
  testSound: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<AppView>('dashboard');
  const [trackingOrderId, setTrackingOrderId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [connectedSSE, setConnectedSSE] = useState(false);

  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [cashRegister, setCashRegister] = useState<CashRegister | null>(null);
  const [cashMovements, setCashMovements] = useState<CashMovement[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [couriers, setCouriers] = useState<Courier[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [allUsers, setAllUsers] = useState<UserAccount[]>([]);
  const [currentUser, setCurrentUser] = useState<UserAccount>({
    id: 'usr-1',
    name: 'Administrador Geral',
    email: 'admin@burgerflow.com',
    role: 'admin',
    pin: '1234',
    active: true
  });
  const [settings, setSettings] = useState<RestaurantSettings>({
    restaurantName: 'Burger & Co. Artesanal',
    tradeName: 'Burger & Co. Lanchonete',
    cnpj: '45.123.789/0001-50',
    phone: '(11) 3210-9876',
    whatsapp: '5511987654321',
    address: 'Rua Augusta, 1420 - Consolação',
    city: 'São Paulo',
    state: 'SP',
    isOpen: true,
    openingHoursDescription: 'Segunda a Domingo das 11:30 às 23:30',
    standardDeliveryFee: 7.00,
    freeDeliveryThreshold: 90.00,
    minOrderValue: 20.00,
    averagePrepTimeMinutes: 20,
    deliveryNeighborhoods: [],
    automatedMessages: {
      recebido: 'Recebemos seu pedido! Estamos verificando os detalhes e logo iniciaremos a preparação.',
      aguardando_confirmacao: 'Aguardando confirmação da lanchonete.',
      confirmado: 'Seu pedido foi confirmado! Já estamos organizando tudo para preparar sua refeição.',
      em_preparacao: '🍔 SEU PEDIDO ESTÁ SENDO PREPARADO! Nossa equipe já começou a preparar tudo com muito carinho.',
      pronto: '✅ Seu pedido está pronto! Você já pode retirar no balcão.',
      saiu_entrega: '🛵 Seu pedido saiu para entrega! Em breve ele chegará até você.',
      entregue: 'Pedido entregue! Agradecemos pela preferência. Esperamos ver você novamente!',
      cancelado: 'Informamos que seu pedido foi cancelado.'
    },
    soundAlertsEnabled: true,
    soundVolume: 0.8,
    printerWidth: '80mm',
    autoAcceptOrders: false,
    kitchenStations: ['Geral', 'Chapa', 'Fritadeira', 'Montagem', 'Bebidas']
  });
  const [notifications, setNotifications] = useState<SystemNotification[]>([]);
  const [auditLogs, setAuditLogs] = useState<SystemAuditLog[]>([]);

  const fetchBootstrapData = useCallback(async () => {
    try {
      const res = await fetch('/api/bootstrap');
      if (!res.ok) throw new Error('Falha ao carregar dados');
      const data = await res.json();
      setCategories(data.categories || []);
      setProducts(data.products || []);
      setInventory(data.inventory || []);
      setOrders(data.orders || []);
      setCashRegister(data.cashRegisters?.find((c: CashRegister) => c.status === 'open') || null);
      setCashMovements(data.cashMovements || []);
      setExpenses(data.expenses || []);
      setCustomers(data.customers || []);
      setCoupons(data.coupons || []);
      setCouriers(data.couriers || []);
      setSuppliers(data.suppliers || []);
      setAllUsers(data.users || []);
      if (data.users && data.users.length > 0) {
        // Keep current selected if valid
        setCurrentUser(prev => data.users.find((u: UserAccount) => u.id === prev.id) || data.users[0]);
      }
      if (data.settings) setSettings(data.settings);
      setNotifications(data.notifications || []);
      setAuditLogs(data.auditLogs || []);
    } catch (e) {
      console.error('Error fetching bootstrap data:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchBootstrapData();
  }, [fetchBootstrapData]);

  // Connect to SSE for real-time updates across all instances
  useEffect(() => {
    let evtSource: EventSource | null = null;
    try {
      evtSource = new EventSource('/api/events');
      evtSource.onopen = () => {
        setConnectedSSE(true);
      };
      evtSource.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          if (payload.type === 'order_created') {
            const newOrder = payload.payload as Order;
            setOrders(prev => [newOrder, ...prev.filter(o => o.id !== newOrder.id)]);
            if (settings.soundAlertsEnabled) {
              playOrderAlertSound(settings.soundVolume);
            }
          } else if (payload.type === 'order_updated') {
            const updatedOrder = payload.payload as Order;
            setOrders(prev => prev.map(o => o.id === updatedOrder.id ? updatedOrder : o));
            if (updatedOrder.status === 'pronto' && settings.soundAlertsEnabled) {
              playReadyAlertSound(settings.soundVolume);
            }
          } else if (payload.type === 'notification') {
            const newNotif = payload.payload as SystemNotification;
            setNotifications(prev => [newNotif, ...prev.filter(n => n.id !== newNotif.id)]);
          } else if (payload.type === 'inventory_updated') {
            setInventory(payload.payload);
          } else if (payload.type === 'cash_register_updated') {
            setCashRegister(payload.payload);
          } else if (payload.type === 'cash_register_closed') {
            setCashRegister(null);
          } else if (payload.type === 'settings_updated') {
            setSettings(payload.payload);
          } else if (payload.type === 'db_reset') {
            fetchBootstrapData();
          }
        } catch (err) {
          console.error('Error parsing SSE event:', err);
        }
      };
      evtSource.onerror = () => {
        setConnectedSSE(false);
      };
    } catch (err) {
      console.warn('SSE initialization failed:', err);
    }

    return () => {
      if (evtSource) {
        evtSource.close();
      }
    };
  }, [settings.soundAlertsEnabled, settings.soundVolume, fetchBootstrapData]);

  const testSound = useCallback(() => {
    playOrderAlertSound(settings.soundVolume);
  }, [settings.soundVolume]);

  const createOrder = async (orderData: Partial<Order>): Promise<Order> => {
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...orderData,
        createdByName: currentUser.name,
        userId: currentUser.id
      })
    });
    if (!res.ok) throw new Error('Erro ao registrar pedido');
    const created = await res.json();
    setOrders(prev => [created, ...prev.filter(o => o.id !== created.id)]);
    if (settings.soundAlertsEnabled) {
      playOrderAlertSound(settings.soundVolume);
    }
    return created;
  };

  const updateOrderStatus = async (
    orderId: string,
    status: OrderStatus,
    reason?: string,
    courierId?: string,
    courierName?: string
  ) => {
    const res = await fetch(`/api/orders/${orderId}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        status,
        updatedBy: currentUser.name,
        reason,
        courierId,
        courierName
      })
    });
    if (!res.ok) throw new Error('Erro ao atualizar status do pedido');
    const updated = await res.json();
    setOrders(prev => prev.map(o => o.id === updated.id ? updated : o));
    if (status === 'pronto' && settings.soundAlertsEnabled) {
      playReadyAlertSound(settings.soundVolume);
    }
  };

  const createProduct = async (product: Partial<Product>) => {
    const res = await fetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product)
    });
    if (!res.ok) throw new Error('Erro ao criar produto');
    const newProd = await res.json();
    setProducts(prev => [...prev, newProd]);
  };

  const updateProduct = async (id: string, product: Partial<Product>) => {
    const res = await fetch(`/api/products/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product)
    });
    if (!res.ok) throw new Error('Erro ao salvar produto');
    const updated = await res.json();
    setProducts(prev => prev.map(p => p.id === id ? updated : p));
  };

  const deleteProduct = async (id: string) => {
    const res = await fetch(`/api/products/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Erro ao excluir produto');
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const registerInventoryMovement = async (data: {
    itemId: string;
    type: string;
    quantity: number;
    reason: string;
    unitCost?: number;
  }) => {
    const res = await fetch('/api/inventory/movement', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...data, userId: currentUser.id })
    });
    if (!res.ok) throw new Error('Erro ao movimentar estoque');
    const result = await res.json();
    if (result.item) {
      setInventory(prev => prev.map(i => i.id === result.item.id ? result.item : i));
    }
  };

  const createInventoryItem = async (data: Partial<InventoryItem>) => {
    const res = await fetch('/api/inventory', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Erro ao adicionar insumo');
    const newItem = await res.json();
    setInventory(prev => [...prev, newItem]);
  };

  const updateInventoryItem = async (id: string, data: Partial<InventoryItem>) => {
    const res = await fetch(`/api/inventory/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Erro ao atualizar insumo');
    const updated = await res.json();
    setInventory(prev => prev.map(i => i.id === id ? updated : i));
  };

  const openCashRegister = async (initialCash: number, notes?: string) => {
    const res = await fetch('/api/cash-register/open', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ initialCash, openedBy: currentUser.name, notes })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Erro ao abrir caixa');
    }
    const created = await res.json();
    setCashRegister(created);
  };

  const closeCashRegister = async (finalCashCounted: number, notes?: string) => {
    const res = await fetch('/api/cash-register/close', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ finalCashCounted, closedBy: currentUser.name, notes })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Erro ao fechar caixa');
    }
    setCashRegister(null);
  };

  const addCashMovement = async (type: 'sangria' | 'suprimento', amount: number, reason: string) => {
    const res = await fetch('/api/cash-register/movement', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type, amount, reason, operator: currentUser.name })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Erro ao registrar movimentação');
    }
    const result = await res.json();
    setCashRegister(result.cashRegister);
    setCashMovements(prev => [result.movement, ...prev]);
  };

  const createExpense = async (expense: Partial<Expense>) => {
    const res = await fetch('/api/expenses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(expense)
    });
    if (!res.ok) throw new Error('Erro ao adicionar despesa');
    const created = await res.json();
    setExpenses(prev => [created, ...prev]);
  };

  const updateExpense = async (id: string, expense: Partial<Expense>) => {
    const res = await fetch(`/api/expenses/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(expense)
    });
    if (!res.ok) throw new Error('Erro ao atualizar despesa');
    const updated = await res.json();
    setExpenses(prev => prev.map(e => e.id === id ? updated : e));
  };

  const deleteExpense = async (id: string) => {
    const res = await fetch(`/api/expenses/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Erro ao excluir despesa');
    setExpenses(prev => prev.filter(e => e.id !== id));
  };

  const updateSettings = async (newSettings: Partial<RestaurantSettings>) => {
    const res = await fetch('/api/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newSettings)
    });
    if (!res.ok) throw new Error('Erro ao salvar configurações');
    const updated = await res.json();
    setSettings(updated);
  };

  const markNotificationAsRead = async (id: string) => {
    await fetch(`/api/notifications/${id}/read`, { method: 'POST' });
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllNotificationsAsRead = async () => {
    await fetch('/api/notifications/read-all', { method: 'POST' });
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const resetDemoData = async () => {
    const res = await fetch('/api/system/reset-demo', { method: 'POST' });
    if (!res.ok) throw new Error('Erro ao restaurar dados');
    await fetchBootstrapData();
  };

  const unreadNotificationsCount = notifications.filter(n => !n.read).length;

  return (
    <AppContext.Provider
      value={{
        currentView,
        setCurrentView,
        currentUser,
        setCurrentUser,
        allUsers,
        trackingOrderId,
        setTrackingOrderId,
        categories,
        products,
        inventory,
        orders,
        cashRegister,
        cashMovements,
        expenses,
        customers,
        coupons,
        couriers,
        suppliers,
        settings,
        notifications,
        auditLogs,
        unreadNotificationsCount,
        loading,
        connectedSSE,
        createOrder,
        updateOrderStatus,
        createProduct,
        updateProduct,
        deleteProduct,
        registerInventoryMovement,
        createInventoryItem,
        updateInventoryItem,
        openCashRegister,
        closeCashRegister,
        addCashMovement,
        createExpense,
        updateExpense,
        deleteExpense,
        updateSettings,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        resetDemoData,
        refreshData: fetchBootstrapData,
        testSound
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
