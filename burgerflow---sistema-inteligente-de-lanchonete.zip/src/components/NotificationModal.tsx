import React from 'react';
import { useApp } from '../context/AppContext.tsx';
import { formatDateTime } from '../utils/formatters.ts';
import { Bell, CheckCheck, X, AlertTriangle, ShoppingBag, DollarSign, ChefHat } from 'lucide-react';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({ isOpen, onClose }) => {
  const {
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    unreadNotificationsCount,
    setCurrentView
  } = useApp();

  if (!isOpen) return null;

  const getIcon = (type: string) => {
    switch (type) {
      case 'novo_pedido':
        return <ShoppingBag className="w-4 h-4 text-amber-600" />;
      case 'estoque_baixo':
        return <AlertTriangle className="w-4 h-4 text-rose-600" />;
      case 'alerta_cozinha':
        return <ChefHat className="w-4 h-4 text-blue-600" />;
      case 'caixa':
      case 'pagamento':
        return <DollarSign className="w-4 h-4 text-emerald-600" />;
      default:
        return <Bell className="w-4 h-4 text-stone-600" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full flex flex-col max-h-[85vh] overflow-hidden border border-stone-200">
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-amber-600" />
            <h3 className="font-semibold text-stone-900 text-sm">Central de Notificações</h3>
            {unreadNotificationsCount > 0 && (
              <span className="text-xs bg-amber-100 text-amber-800 font-semibold px-2 py-0.5 rounded-full">
                {unreadNotificationsCount} novas
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {unreadNotificationsCount > 0 && (
              <button
                type="button"
                onClick={() => markAllNotificationsAsRead()}
                className="text-xs text-stone-600 hover:text-stone-900 font-medium flex items-center gap-1 hover:underline"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                Marcar todas
              </button>
            )}
            <button
              onClick={onClose}
              className="text-stone-400 hover:text-stone-700 p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* List */}
        <div className="overflow-y-auto p-3 space-y-2 flex-1 divide-y divide-stone-100">
          {notifications.length === 0 ? (
            <div className="py-12 text-center text-stone-400 text-sm">
              Nenhuma notificação registrada no momento.
            </div>
          ) : (
            notifications.map((notif) => (
              <div
                key={notif.id}
                onClick={() => {
                  if (!notif.read) markNotificationAsRead(notif.id);
                  if (notif.type === 'novo_pedido') {
                    setCurrentView('orders');
                    onClose();
                  } else if (notif.type === 'estoque_baixo') {
                    setCurrentView('inventory');
                    onClose();
                  }
                }}
                className={`p-3 rounded-lg cursor-pointer transition-colors flex items-start gap-3 ${
                  notif.read ? 'bg-white hover:bg-stone-50' : 'bg-amber-50/50 hover:bg-amber-50 border-l-3 border-amber-500'
                }`}
              >
                <div className="mt-0.5 p-1.5 bg-stone-100 rounded-md shrink-0">
                  {getIcon(notif.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-xs text-stone-900 truncate">
                      {notif.title}
                    </span>
                    <span className="text-[11px] text-stone-400 shrink-0 font-mono">
                      {formatDateTime(notif.timestamp)}
                    </span>
                  </div>
                  <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                    {notif.message}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-stone-200 bg-stone-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-stone-700 bg-white border border-stone-300 rounded-lg shadow-2xs hover:bg-stone-50 transition-colors"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
