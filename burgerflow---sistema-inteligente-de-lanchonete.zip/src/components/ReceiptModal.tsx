import React from 'react';
import type { Order, RestaurantSettings } from '../types/index.ts';
import { formatCurrency, formatDateTime, ORDER_TYPE_LABELS, PAYMENT_METHOD_LABELS } from '../utils/formatters.ts';
import { Printer, X, Check } from 'lucide-react';

interface ReceiptModalProps {
  order: Order | null;
  settings: RestaurantSettings;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ order, settings, onClose }) => {
  if (!order) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header bar */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5 text-stone-700" />
            <h3 className="font-semibold text-stone-900 text-sm">Comprovante de Pedido #{order.orderNumber}</h3>
          </div>
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-stone-700 p-1 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Receipt Body */}
        <div className="p-6 overflow-y-auto bg-stone-100 flex justify-center">
          <div
            id="printable-receipt"
            className="bg-white p-6 shadow-sm border border-stone-200 text-stone-900 font-mono text-xs w-[320px] rounded-sm leading-relaxed"
          >
            {/* Store Header */}
            <div className="text-center pb-3 border-b border-dashed border-stone-400 mb-3">
              <div className="font-bold text-sm tracking-wide">{settings.tradeName.toUpperCase()}</div>
              <div className="text-[11px] text-stone-600">{settings.address}</div>
              <div className="text-[11px] text-stone-600">Tel/WhatsApp: {settings.phone}</div>
              <div className="text-[10px] text-stone-500 mt-1">CNPJ: {settings.cnpj}</div>
            </div>

            {/* Order Meta */}
            <div className="pb-3 border-b border-dashed border-stone-400 mb-3 space-y-1">
              <div className="flex justify-between font-bold text-sm">
                <span>PEDIDO: #{order.orderNumber}</span>
                <span>{ORDER_TYPE_LABELS[order.orderType].toUpperCase()}</span>
              </div>
              <div className="text-stone-600">Data: {formatDateTime(order.createdAt)}</div>
              <div>Cliente: <span className="font-semibold">{order.customerName}</span></div>
              <div>Telefone: {order.customerPhone}</div>
              {order.tableNumber && (
                <div className="font-bold text-stone-800">Local: {order.tableNumber}</div>
              )}
              {order.orderType === 'delivery' && order.customerAddress && (
                <div className="mt-1 pt-1 border-t border-dotted border-stone-300">
                  <div className="font-bold">ENDEREÇO DE ENTREGA:</div>
                  <div>{order.customerAddress.street}, {order.customerAddress.number}</div>
                  <div>Bairro: {order.customerAddress.neighborhood}</div>
                  {order.customerAddress.complement && <div>Compl: {order.customerAddress.complement}</div>}
                  {order.customerAddress.reference && <div>Ref: {order.customerAddress.reference}</div>}
                </div>
              )}
            </div>

            {/* Items List */}
            <div className="pb-3 border-b border-dashed border-stone-400 mb-3">
              <div className="font-bold mb-2 flex justify-between border-b border-stone-200 pb-1">
                <span>QTD ITEM</span>
                <span>TOTAL</span>
              </div>
              <div className="space-y-2">
                {order.items.map((item, idx) => (
                  <div key={idx} className="space-y-0.5">
                    <div className="flex justify-between items-start font-medium">
                      <span>{item.quantity}x {item.productName}</span>
                      <span>{formatCurrency(item.totalPrice)}</span>
                    </div>
                    {item.addOns && item.addOns.length > 0 && (
                      <div className="text-[11px] text-stone-600 pl-3">
                        {item.addOns.map(a => `+ ${a.name} (${formatCurrency(a.price)})`).join(', ')}
                      </div>
                    )}
                    {item.removedIngredients && item.removedIngredients.length > 0 && (
                      <div className="text-[11px] text-rose-600 pl-3">
                        SEM: {item.removedIngredients.join(', ')}
                      </div>
                    )}
                    {item.notes && (
                      <div className="text-[11px] text-amber-700 italic pl-3">
                        Obs: {item.notes}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Financial Summary */}
            <div className="pb-3 border-b border-dashed border-stone-400 mb-3 space-y-1">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>{formatCurrency(order.subtotal)}</span>
              </div>
              {order.deliveryFee > 0 && (
                <div className="flex justify-between">
                  <span>Taxa de Entrega:</span>
                  <span>{formatCurrency(order.deliveryFee)}</span>
                </div>
              )}
              {order.discount > 0 && (
                <div className="flex justify-between text-rose-600">
                  <span>Desconto ({order.couponCode || 'Promo'}):</span>
                  <span>- {formatCurrency(order.discount)}</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-sm pt-1 border-t border-stone-300">
                <span>TOTAL:</span>
                <span>{formatCurrency(order.total)}</span>
              </div>
            </div>

            {/* Payment Details */}
            <div className="pb-3 border-b border-dashed border-stone-400 mb-3 space-y-1">
              <div className="flex justify-between">
                <span>Forma de Pagto:</span>
                <span className="font-semibold">{PAYMENT_METHOD_LABELS[order.paymentMethod]}</span>
              </div>
              <div className="flex justify-between">
                <span>Status Pagto:</span>
                <span className={order.paymentStatus === 'pago' ? 'text-emerald-700 font-bold' : 'text-amber-700'}>
                  {order.paymentStatus.toUpperCase()}
                </span>
              </div>
              {order.paymentMethod === 'dinheiro' && order.changeFor && (
                <>
                  <div className="flex justify-between">
                    <span>Troco para:</span>
                    <span>{formatCurrency(order.changeFor)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-stone-800">
                    <span>Levar de troco:</span>
                    <span>{formatCurrency(order.changeFor - order.total)}</span>
                  </div>
                </>
              )}
            </div>

            {/* Footer Notice */}
            <div className="text-center text-[10px] text-stone-500 pt-1">
              <div>OBRIGADO PELA PREFERÊNCIA!</div>
              <div>Volte sempre à {settings.restaurantName}</div>
              <div className="mt-2 text-[9px]">SISTEMA BURGERFLOW OPERACIONAL</div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-4 border-t border-stone-200 bg-stone-50 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900 bg-white border border-stone-300 rounded-lg shadow-2xs hover:bg-stone-50 transition-colors"
          >
            Fechar
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="px-4 py-2 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-lg shadow-2xs transition-colors flex items-center gap-2"
          >
            <Printer className="w-4 h-4" />
            Imprimir Cupom
          </button>
        </div>
      </div>
    </div>
  );
};
