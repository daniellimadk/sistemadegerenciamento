import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { NotificationModal } from './NotificationModal.tsx';
import {
  Bell,
  Volume2,
  VolumeX,
  Smartphone,
  RotateCcw,
  User,
  Radio,
  CheckCircle2,
  Menu
} from 'lucide-react';

interface HeaderProps {
  onToggleMobileMenu?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onToggleMobileMenu }) => {
  const {
    settings,
    updateSettings,
    unreadNotificationsCount,
    testSound,
    currentUser,
    setCurrentUser,
    allUsers,
    setCurrentView,
    resetDemoData,
    connectedSSE
  } = useApp();

  const [showNotifModal, setShowNotifModal] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);

  const toggleSound = () => {
    updateSettings({ soundAlertsEnabled: !settings.soundAlertsEnabled });
  };

  return (
    <>
      <header className="h-16 bg-white border-b border-stone-200 px-4 lg:px-6 flex items-center justify-between gap-4 sticky top-0 z-30">
        {/* Left: Mobile hamburger + System Brand & Breadcrumb */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onToggleMobileMenu}
            className="lg:hidden p-2 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-lg"
            aria-label="Abrir menu"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          <div className="flex items-center gap-2">
            <span className="font-bold text-base tracking-tight text-stone-900">
              {settings.restaurantName}
            </span>
            <span className="hidden sm:inline-block text-stone-400 text-xs">/</span>
            <span className="hidden sm:inline-block text-xs font-medium text-stone-500">
              Painel de Operações
            </span>
          </div>

          {/* Real-time SSE indicator */}
          <div className="hidden md:flex items-center gap-1.5 text-[11px] text-stone-500 pl-2">
            <span
              className={`w-2 h-2 rounded-full ${
                connectedSSE ? 'bg-emerald-500' : 'bg-amber-400 animate-pulse'
              }`}
              title={connectedSSE ? 'Tempo real ativo via SSE' : 'Conectando ao servidor...'}
            />
            <span className="font-mono text-[10px]">
              {connectedSSE ? 'AO VIVO' : 'CONECTANDO'}
            </span>
          </div>
        </div>

        {/* Right Action Cluster */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Sound Toggle & Test */}
          <div className="flex items-center border border-stone-200 rounded-lg p-0.5 bg-stone-50">
            <button
              type="button"
              onClick={toggleSound}
              title={settings.soundAlertsEnabled ? 'Desativar som de alerta' : 'Ativar som de alerta'}
              className={`p-1.5 rounded-md text-xs transition-colors ${
                settings.soundAlertsEnabled
                  ? 'text-amber-700 bg-amber-100 hover:bg-amber-200'
                  : 'text-stone-400 hover:text-stone-700'
              }`}
            >
              {settings.soundAlertsEnabled ? (
                <Volume2 className="w-4 h-4" />
              ) : (
                <VolumeX className="w-4 h-4" />
              )}
            </button>
            <button
              type="button"
              onClick={testSound}
              title="Testar sinal sonoro de pedidos"
              className="px-2 py-1 text-[11px] font-medium text-stone-600 hover:text-stone-900 hover:bg-stone-200 rounded-md transition-colors"
            >
              Testar
            </button>
          </div>

          {/* Quick Open Customer Menu / Online Ordering */}
          <button
            type="button"
            onClick={() => setCurrentView('customer-menu')}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors whitespace-nowrap"
          >
            <Smartphone className="w-4 h-4 text-amber-600" />
            <span>Cardápio Cliente</span>
          </button>

          {/* Notifications Bell */}
          <button
            type="button"
            onClick={() => setShowNotifModal(true)}
            className="relative p-2 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors"
            title="Notificações do sistema"
          >
            <Bell className="w-5 h-5" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-amber-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                {unreadNotificationsCount > 9 ? '9+' : unreadNotificationsCount}
              </span>
            )}
          </button>

          {/* User Profile Switcher */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowUserDropdown(!showUserDropdown)}
              className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 bg-stone-100 hover:bg-stone-200 rounded-lg text-xs font-medium text-stone-800 transition-colors"
            >
              <div className="w-6 h-6 rounded-md bg-stone-900 text-white flex items-center justify-center text-[10px] font-bold uppercase">
                {currentUser.name.substring(0, 2)}
              </div>
              <div className="hidden md:block text-left">
                <div className="font-semibold leading-none">{currentUser.name}</div>
                <div className="text-[10px] text-stone-500 capitalize leading-tight mt-0.5">
                  {currentUser.role}
                </div>
              </div>
            </button>

            {showUserDropdown && (
              <div className="absolute right-0 mt-2 w-56 bg-white border border-stone-200 rounded-xl shadow-xl py-2 z-50">
                <div className="px-3 py-2 border-b border-stone-100 text-xs text-stone-500">
                  Alternar Operador / Perfil:
                </div>
                {allUsers.map((user) => (
                  <button
                    key={user.id}
                    type="button"
                    onClick={() => {
                      setCurrentUser(user);
                      setShowUserDropdown(false);
                    }}
                    className={`w-full px-3 py-2 text-left text-xs flex items-center justify-between hover:bg-stone-50 transition-colors ${
                      currentUser.id === user.id ? 'font-semibold text-amber-700 bg-amber-50/50' : 'text-stone-700'
                    }`}
                  >
                    <div>
                      <div>{user.name}</div>
                      <div className="text-[10px] text-stone-400 capitalize">{user.role}</div>
                    </div>
                    {currentUser.id === user.id && (
                      <CheckCircle2 className="w-4 h-4 text-amber-600" />
                    )}
                  </button>
                ))}
                <div className="border-t border-stone-100 mt-1 pt-1 px-3">
                  <button
                    type="button"
                    onClick={() => {
                      if (confirm('Deseja recarregar os dados de demonstração da lanchonete?')) {
                        resetDemoData();
                      }
                      setShowUserDropdown(false);
                    }}
                    className="w-full py-1.5 text-left text-xs text-rose-600 hover:text-rose-700 flex items-center gap-1.5"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Restaurar Dados Demo
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      <NotificationModal
        isOpen={showNotifModal}
        onClose={() => setShowNotifModal(false)}
      />
    </>
  );
};
